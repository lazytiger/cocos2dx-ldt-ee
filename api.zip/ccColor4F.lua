--------------------------------
-- @type ccColor4F
-- @extends #

--------------------------------
-- @field [parent=#ccColor4F] #GLfloat r

--------------------------------
-- @field [parent=#ccColor4F] #GLfloat g

--------------------------------
-- @field [parent=#ccColor4F] #GLfloat b

--------------------------------
-- @field [parent=#ccColor4F] #GLfloat a

return nil
