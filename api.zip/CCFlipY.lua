--------------------------------
-- @type CCFlipY
-- @extends CCActionInstant#CCActionInstant

--------------------------------
-- @function [parent=#CCFlipY] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipY] create
-- @param self
-- @param #bool y
-- @return #CCFlipY

return nil
