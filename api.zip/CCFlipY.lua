--------------------------------
-- @module CCFlipY

--------------------------------
-- @function [parent=#CCFlipY] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipY] create
-- @param self
-- @param #bool y
-- @return #CCFlipY

--------------------------------
-- @function [parent=#CCFlipY] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipY] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipY] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFlipY] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCFlipY] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipY] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipY] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFlipY] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFlipY] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFlipY] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCFlipY] release
-- @param self

--------------------------------
-- @function [parent=#CCFlipY] retain
-- @param self

--------------------------------
-- @function [parent=#CCFlipY] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipY] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFlipY] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipY] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCFlipY] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
