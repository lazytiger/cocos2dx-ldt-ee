--------------------------------
-- @type ccV2F_C4F_T2F_Quad
-- @extends #

--------------------------------
-- @field [parent=#ccV2F_C4F_T2F_Quad] #ccV2F_C4F_T2F bl

--------------------------------
-- @field [parent=#ccV2F_C4F_T2F_Quad] #ccV2F_C4F_T2F br

--------------------------------
-- @field [parent=#ccV2F_C4F_T2F_Quad] #ccV2F_C4F_T2F tl

--------------------------------
-- @field [parent=#ccV2F_C4F_T2F_Quad] #ccV2F_C4F_T2F tr

return nil
