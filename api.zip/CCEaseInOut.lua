--------------------------------
-- @module CCEaseInOut

--------------------------------
-- @function [parent=#CCEaseInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCEaseInOut

--------------------------------
-- @function [parent=#CCEaseInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return CCEaseRateAction#CCEaseRateAction

--------------------------------
-- @function [parent=#CCEaseInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseInOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseInOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseInOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseInOut] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseInOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseInOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseInOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseInOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseInOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseInOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseInOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseInOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseInOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseInOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseInOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseInOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseInOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseInOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
