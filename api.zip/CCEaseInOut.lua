--------------------------------
-- @type CCEaseInOut
-- @extends CCEaseRateAction#CCEaseRateAction

--------------------------------
-- @function [parent=#CCEaseInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCEaseInOut

return nil
