--------------------------------
-- @type CCWaves
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCWaves] getAmplitude
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCWaves] setAmplitude
-- @param self
-- @param #float fAmplitude

--------------------------------
-- @function [parent=#CCWaves] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCWaves] setAmplitudeRate
-- @param self
-- @param #float fAmplitudeRate

--------------------------------
-- @function [parent=#CCWaves] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int waves
-- @param #float amplitude
-- @param #bool horizontal
-- @param #bool vertical
-- @return #CCWaves

return nil
