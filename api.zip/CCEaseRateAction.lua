--------------------------------
-- @module CCEaseRateAction

--------------------------------
-- @function [parent=#CCEaseRateAction] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseRateAction] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCEaseRateAction

--------------------------------
-- @function [parent=#CCEaseRateAction] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseRateAction] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseRateAction] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseRateAction] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseRateAction] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseRateAction] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseRateAction] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseRateAction] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseRateAction] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseRateAction] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseRateAction] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseRateAction] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseRateAction] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseRateAction] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseRateAction] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseRateAction] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseRateAction] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseRateAction] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseRateAction] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseRateAction] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseRateAction] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseRateAction] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseRateAction] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
