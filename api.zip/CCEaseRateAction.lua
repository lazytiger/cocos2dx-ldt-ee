--------------------------------
-- @type CCEaseRateAction
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseRateAction] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseRateAction] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCEaseRateAction

return nil
