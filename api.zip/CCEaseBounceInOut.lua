--------------------------------
-- @type CCEaseBounceInOut
-- @extends CCEaseBounce#CCEaseBounce

--------------------------------
-- @function [parent=#CCEaseBounceInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBounceInOut

return nil
