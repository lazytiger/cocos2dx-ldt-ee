--------------------------------
-- @module CCEaseBounceInOut

--------------------------------
-- @function [parent=#CCEaseBounceInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceInOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBounceInOut

--------------------------------
-- @function [parent=#CCEaseBounceInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceInOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCEaseBounce#CCEaseBounce

--------------------------------
-- @function [parent=#CCEaseBounceInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceInOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBounceInOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceInOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseBounceInOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceInOut] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceInOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceInOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseBounceInOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseBounceInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceInOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBounceInOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBounceInOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBounceInOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseBounceInOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseBounceInOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseBounceInOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceInOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBounceInOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceInOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseBounceInOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
