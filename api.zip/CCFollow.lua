--------------------------------
-- @module CCFollow

--------------------------------
-- @function [parent=#CCFollow] isBoundarySet
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFollow] setBoudarySet
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCFollow] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFollow] create
-- @param CCNode#CCNode pFollowedNode
-- @param CCRect#CCRect rect
-- @return #CCFollow

--------------------------------
-- @function [parent=#CCFollow] create
-- @param CCNode#CCNode pFollowedNode
-- @return #CCFollow

--------------------------------
-- @function [parent=#CCFollow] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFollow] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFollow] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFollow] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFollow] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCFollow] release
-- @param self

--------------------------------
-- @function [parent=#CCFollow] retain
-- @param self

--------------------------------
-- @function [parent=#CCFollow] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFollow] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFollow] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCFollow] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCFollow] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
