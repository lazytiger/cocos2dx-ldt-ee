--------------------------------
-- @type CCFollow
-- @extends CCAction#CCAction

--------------------------------
-- @function [parent=#CCFollow] isBoundarySet
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFollow] setBoudarySet
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCFollow] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFollow] create
-- @param self
-- @param CCNode#CCNode pFollowedNode
-- @param CCRect#CCRect rect
-- @return #CCFollow

--------------------------------
-- @function [parent=#CCFollow] create
-- @param self
-- @param CCNode#CCNode pFollowedNode
-- @return #CCFollow

return nil
