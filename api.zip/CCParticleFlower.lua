--------------------------------
-- @type CCParticleFlower
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleFlower] create
-- @param self
-- @return #CCParticleFlower

return nil
