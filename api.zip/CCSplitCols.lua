--------------------------------
-- @module CCSplitCols

--------------------------------
-- @function [parent=#CCSplitCols] create
-- @param #float duration
-- @param #int nCols
-- @return #CCSplitCols

--------------------------------
-- @function [parent=#CCSplitCols] tile
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccQuad3

--------------------------------
-- @function [parent=#CCSplitCols] originalTile
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccQuad3

--------------------------------
-- @function [parent=#CCSplitCols] setTile
-- @param self
-- @param CCPoint#CCPoint pos
-- @param #ccQuad3 coords

--------------------------------
-- @function [parent=#CCSplitCols] getGrid
-- @param self
-- @return CCGridBase#CCGridBase

--------------------------------
-- @function [parent=#CCSplitCols] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSplitCols] getGrid
-- @param self
-- @return CCGridBase#CCGridBase

--------------------------------
-- @function [parent=#CCSplitCols] create
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return CCGridAction#CCGridAction

--------------------------------
-- @function [parent=#CCSplitCols] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSplitCols] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSplitCols] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCSplitCols] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSplitCols] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSplitCols] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSplitCols] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSplitCols] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCSplitCols] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCSplitCols] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSplitCols] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCSplitCols] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCSplitCols] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSplitCols] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCSplitCols] release
-- @param self

--------------------------------
-- @function [parent=#CCSplitCols] retain
-- @param self

--------------------------------
-- @function [parent=#CCSplitCols] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSplitCols] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSplitCols] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCSplitCols] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCSplitCols] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
