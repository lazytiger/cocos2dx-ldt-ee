--------------------------------
-- @type CCSplitCols
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCSplitCols] create
-- @param self
-- @param #float duration
-- @param #int nCols
-- @return #CCSplitCols

return nil
