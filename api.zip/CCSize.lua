--------------------------------
-- @module CCSize

--------------------------------
-- @field [parent=#CCSize] #float width

--------------------------------
-- @field [parent=#CCSize] #float height

--------------------------------
-- @function [parent=#CCSize] equals
-- @param self
-- @param #CCSize target
-- @return #bool

return nil
