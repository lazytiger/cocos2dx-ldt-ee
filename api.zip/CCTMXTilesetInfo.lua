--------------------------------
-- @module CCTMXTilesetInfo

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] rectForGID
-- @param self
-- @param #int gid
-- @return CCRect#CCRect

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] release
-- @param self

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] retain
-- @param self

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
