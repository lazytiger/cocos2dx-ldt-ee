--------------------------------
-- @type CCTMXTilesetInfo
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCTMXTilesetInfo] rectForGID
-- @param self
-- @param #int gid
-- @return CCRect#CCRect

return nil
