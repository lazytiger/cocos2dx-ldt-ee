--------------------------------
-- @type CCShaky3D
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCShaky3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int range
-- @param #bool shakeZ
-- @return #CCShaky3D

return nil
