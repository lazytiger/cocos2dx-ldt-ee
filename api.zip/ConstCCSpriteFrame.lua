-------------------------------
-- @field [parent=#global] CCSpriteFrame#CCSpriteFrame CCSpriteFrame preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteFrame#CCSpriteFrame CCSpriteFrame preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteFrame#CCSpriteFrame CCSpriteFrame preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteFrame#CCSpriteFrame CCSpriteFrame preloaded module

