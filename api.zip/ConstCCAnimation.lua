-------------------------------
-- @field [parent=#global] CCAnimationFrame#CCAnimationFrame CCAnimationFrame preloaded module

-------------------------------
-- @field [parent=#global] CCAnimation#CCAnimation CCAnimation preloaded module

-------------------------------
-- @field [parent=#global] CCAnimationFrame#CCAnimationFrame CCAnimationFrame preloaded module

-------------------------------
-- @field [parent=#global] CCAnimation#CCAnimation CCAnimation preloaded module

-------------------------------
-- @field [parent=#global] CCAnimationFrame#CCAnimationFrame CCAnimationFrame preloaded module

-------------------------------
-- @field [parent=#global] CCAnimation#CCAnimation CCAnimation preloaded module

-------------------------------
-- @field [parent=#global] CCAnimationFrame#CCAnimationFrame CCAnimationFrame preloaded module

-------------------------------
-- @field [parent=#global] CCAnimation#CCAnimation CCAnimation preloaded module

