--------------------------------
-- @type CCTransitionShrinkGrow
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionShrinkGrow] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionShrinkGrow

return nil
