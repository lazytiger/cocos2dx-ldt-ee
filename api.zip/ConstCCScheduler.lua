-------------------------------
-- @field [parent=#global] CCTimer#CCTimer CCTimer preloaded module

-------------------------------
-- @field [parent=#global] CCScheduler#CCScheduler CCScheduler preloaded module

-------------------------------
-- @field [parent=#global] CCTimer#CCTimer CCTimer preloaded module

-------------------------------
-- @field [parent=#global] CCScheduler#CCScheduler CCScheduler preloaded module

-------------------------------
-- @field [parent=#global] CCTimer#CCTimer CCTimer preloaded module

-------------------------------
-- @field [parent=#global] CCScheduler#CCScheduler CCScheduler preloaded module

-------------------------------
-- @field [parent=#global] CCTimer#CCTimer CCTimer preloaded module

-------------------------------
-- @field [parent=#global] CCScheduler#CCScheduler CCScheduler preloaded module

