--------------------------------
-- @type CCAnimationFrame
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCAnimationFrame] initWithSpriteFrame
-- @param self
-- @param CCSpriteFrame#CCSpriteFrame spriteFrame
-- @param #float delayUnits
-- @param CCDictionary#CCDictionary userInfo
-- @return #bool

--------------------------------
-- @function [parent=#CCAnimationFrame] getSpriteFrame
-- @param self
-- @return CCSpriteFrame#CCSpriteFrame

--------------------------------
-- @function [parent=#CCAnimationFrame] setSpriteFrame
-- @param self
-- @param CCSpriteFrame#CCSpriteFrame pSpFrame

--------------------------------
-- @function [parent=#CCAnimationFrame] getDelayUnits
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAnimationFrame] setDelayUnits
-- @param self
-- @param #float fDelayUnits

--------------------------------
-- @function [parent=#CCAnimationFrame] getUserInfo
-- @param self
-- @return CCDictionary#CCDictionary

--------------------------------
-- @function [parent=#CCAnimationFrame] setUserInfo
-- @param self
-- @param CCDictionary#CCDictionary pDict

return nil
