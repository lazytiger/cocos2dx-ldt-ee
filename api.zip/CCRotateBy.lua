--------------------------------
-- @module CCRotateBy

--------------------------------
-- @function [parent=#CCRotateBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRotateBy] create
-- @param #float duration
-- @param #float fDeltaAngle
-- @return #CCRotateBy

--------------------------------
-- @function [parent=#CCRotateBy] create
-- @param #float duration
-- @param #float fDeltaAngleX
-- @param #float DeltaAngleY
-- @return #CCRotateBy

--------------------------------
-- @function [parent=#CCRotateBy] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRotateBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRotateBy] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCRotateBy] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRotateBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRotateBy] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRotateBy] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRotateBy] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCRotateBy] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCRotateBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRotateBy] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCRotateBy] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCRotateBy] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCRotateBy] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCRotateBy] release
-- @param self

--------------------------------
-- @function [parent=#CCRotateBy] retain
-- @param self

--------------------------------
-- @function [parent=#CCRotateBy] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRotateBy] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCRotateBy] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCRotateBy] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCRotateBy] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
