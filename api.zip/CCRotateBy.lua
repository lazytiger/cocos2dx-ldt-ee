--------------------------------
-- @type CCRotateBy
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRotateBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRotateBy] create
-- @param self
-- @param #float duration
-- @param #float fDeltaAngle
-- @return #CCRotateBy

--------------------------------
-- @function [parent=#CCRotateBy] create
-- @param self
-- @param #float duration
-- @param #float fDeltaAngleX
-- @param #float DeltaAngleY
-- @return #CCRotateBy

return nil
