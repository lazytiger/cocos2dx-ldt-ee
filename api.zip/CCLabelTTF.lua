--------------------------------
-- @type CCLabelTTF
-- @extends CCSprite#CCSprite

--------------------------------
-- @function [parent=#CCLabelTTF] init
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLabelTTF] setString
-- @param self
-- @param #char label

--------------------------------
-- @function [parent=#CCLabelTTF] getString
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCLabelTTF] getHorizontalAlignment
-- @param self
-- @return CCTextAlignment#CCTextAlignment

--------------------------------
-- @function [parent=#CCLabelTTF] setHorizontalAlignment
-- @param self
-- @param CCTextAlignment#CCTextAlignment alignment

--------------------------------
-- @function [parent=#CCLabelTTF] getVerticalAlignment
-- @param self
-- @return CCVerticalTextAlignment#CCVerticalTextAlignment

--------------------------------
-- @function [parent=#CCLabelTTF] setVerticalAlignment
-- @param self
-- @param CCVerticalTextAlignment#CCVerticalTextAlignment verticalAlignment

--------------------------------
-- @function [parent=#CCLabelTTF] getDimensions
-- @param self
-- @return CCSize#CCSize

--------------------------------
-- @function [parent=#CCLabelTTF] setDimensions
-- @param self
-- @param CCSize#CCSize dim

--------------------------------
-- @function [parent=#CCLabelTTF] getFontSize
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCLabelTTF] setFontSize
-- @param self
-- @param #float fontSize

--------------------------------
-- @function [parent=#CCLabelTTF] getFontName
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCLabelTTF] setFontName
-- @param self
-- @param #char fontName

--------------------------------
-- @function [parent=#CCLabelTTF] create
-- @param self
-- @param #char str
-- @param #char fontName
-- @param #float fontSize
-- @param CCSize#CCSize dimensions
-- @param CCTextAlignment#CCTextAlignment hAlignment
-- @param CCVerticalTextAlignment#CCVerticalTextAlignment vAlignment
-- @return #CCLabelTTF

--------------------------------
-- @function [parent=#CCLabelTTF] create
-- @param self
-- @param #char str
-- @param #char fontName
-- @param #float fontSize
-- @param CCSize#CCSize dimensions
-- @param CCTextAlignment#CCTextAlignment hAlignment
-- @return #CCLabelTTF

--------------------------------
-- @function [parent=#CCLabelTTF] create
-- @param self
-- @param #char str
-- @param #char fontName
-- @param #float fontSize
-- @return #CCLabelTTF

--------------------------------
-- @function [parent=#CCLabelTTF] create
-- @param self
-- @return #CCLabelTTF

return nil
