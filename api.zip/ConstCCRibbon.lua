-------------------------------
-- @field [parent=#global] CCRibbon:#CCRibbon: CCRibbon: preloaded module

-------------------------------
-- @field [parent=#global] CCRibbon:#CCRibbon: CCRibbon: preloaded module

-------------------------------
-- @field [parent=#global] CCRibbon:#CCRibbon: CCRibbon: preloaded module

-------------------------------
-- @field [parent=#global] CCRibbon:#CCRibbon: CCRibbon: preloaded module

