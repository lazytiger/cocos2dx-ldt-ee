--------------------------------
-- @type CCTiledGrid3DAction
-- @extends CCGridAction#CCGridAction

--------------------------------
-- @function [parent=#CCTiledGrid3DAction] tile
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccQuad3

--------------------------------
-- @function [parent=#CCTiledGrid3DAction] originalTile
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccQuad3

--------------------------------
-- @function [parent=#CCTiledGrid3DAction] setTile
-- @param self
-- @param CCPoint#CCPoint pos
-- @param #ccQuad3 coords

--------------------------------
-- @function [parent=#CCTiledGrid3DAction] getGrid
-- @param self
-- @return CCGridBase#CCGridBase

return nil
