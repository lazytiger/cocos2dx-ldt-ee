--------------------------------
-- @type ccBezierConfig
-- @extends #

--------------------------------
-- @field [parent=#ccBezierConfig] #CCPoint endPosition

--------------------------------
-- @field [parent=#ccBezierConfig] #CCPoint controlPoint_1

--------------------------------
-- @field [parent=#ccBezierConfig] #CCPoint controlPoint_2

return nil
