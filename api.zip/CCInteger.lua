--------------------------------
-- @module CCInteger

--------------------------------
-- @function [parent=#CCInteger] getValue
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCInteger] create
-- @param #int v
-- @return #CCInteger

--------------------------------
-- @function [parent=#CCInteger] release
-- @param self

--------------------------------
-- @function [parent=#CCInteger] retain
-- @param self

--------------------------------
-- @function [parent=#CCInteger] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCInteger] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCInteger] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCInteger] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCInteger] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
