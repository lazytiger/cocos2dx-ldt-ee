--------------------------------
-- @type CCInteger
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCInteger] getValue
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCInteger] create
-- @param self
-- @param #int v
-- @return #CCInteger

return nil
