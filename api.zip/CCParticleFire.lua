--------------------------------
-- @type CCParticleFire
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleFire] create
-- @param self
-- @return #CCParticleFire

return nil
