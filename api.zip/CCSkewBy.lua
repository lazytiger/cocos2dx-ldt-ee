--------------------------------
-- @type CCSkewBy
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSkewBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSkewBy] create
-- @param self
-- @param #float t
-- @param #float deltaSkewX
-- @param #float deltaSkewY
-- @return #CCSkewBy

return nil
