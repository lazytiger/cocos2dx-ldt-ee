--------------------------------
-- @module CCSkewBy

--------------------------------
-- @function [parent=#CCSkewBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSkewBy] create
-- @param self
-- @param #float t
-- @param #float deltaSkewX
-- @param #float deltaSkewY
-- @return #CCSkewBy

--------------------------------
-- @function [parent=#CCSkewBy] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSkewBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSkewBy] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCSkewBy] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSkewBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSkewBy] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSkewBy] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSkewBy] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCSkewBy] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCSkewBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSkewBy] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCSkewBy] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCSkewBy] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSkewBy] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCSkewBy] release
-- @param self

--------------------------------
-- @function [parent=#CCSkewBy] retain
-- @param self

--------------------------------
-- @function [parent=#CCSkewBy] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSkewBy] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSkewBy] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCSkewBy] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCSkewBy] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
