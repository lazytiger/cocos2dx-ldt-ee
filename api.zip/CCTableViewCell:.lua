--------------------------------
-- @type CCTableViewCell:
-- @extends CCNode#CCNode

--------------------------------
-- @function [parent=#CCTableViewCell:] getIdx
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTableViewCell:] setIdx
-- @param self
-- @param #int uIdx

--------------------------------
-- @function [parent=#CCTableViewCell:] reset
-- @param self

--------------------------------
-- @function [parent=#CCTableViewCell:] setObjectID
-- @param self
-- @param #int uIdx

--------------------------------
-- @function [parent=#CCTableViewCell:] getObjectID
-- @param self
-- @return #int

return nil
