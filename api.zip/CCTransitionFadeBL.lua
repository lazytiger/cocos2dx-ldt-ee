--------------------------------
-- @type CCTransitionFadeBL
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionFadeBL] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionFadeBL

return nil
