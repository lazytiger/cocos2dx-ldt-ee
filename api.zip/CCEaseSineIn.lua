--------------------------------
-- @type CCEaseSineIn
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseSineIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseSineIn

return nil
