--------------------------------
-- @type CCTransitionZoomFlipY
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionZoomFlipY] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene s
-- @param #tOrientation o
-- @return #CCTransitionZoomFlipY

return nil
