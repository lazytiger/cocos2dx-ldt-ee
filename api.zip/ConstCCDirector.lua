--------------------------------
-- @field [parent=#global] #ccDirectorProjection kCCDirectorProjection2D

--------------------------------
-- @field [parent=#global] #ccDirectorProjection kCCDirectorProjection3D

--------------------------------
-- @field [parent=#global] #ccDirectorProjection kCCDirectorProjectionCustom

--------------------------------
-- @field [parent=#global] #ccDirectorProjection kCCDirectorProjectionDefault

-------------------------------
-- @field [parent=#global] CCDirector#CCDirector CCDirector preloaded module

