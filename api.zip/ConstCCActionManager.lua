-------------------------------
-- @field [parent=#global] CCActionManager#CCActionManager CCActionManager preloaded module

-------------------------------
-- @field [parent=#global] CCActionManager#CCActionManager CCActionManager preloaded module

-------------------------------
-- @field [parent=#global] CCActionManager#CCActionManager CCActionManager preloaded module

-------------------------------
-- @field [parent=#global] CCActionManager#CCActionManager CCActionManager preloaded module

