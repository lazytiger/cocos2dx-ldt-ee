--------------------------------
-- @type CCTransitionSplitRows
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionSplitRows] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionSplitRows

return nil
