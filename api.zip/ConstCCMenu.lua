--------------------------------
-- @field [parent=#global] # kCCMenuStateWaiting

--------------------------------
-- @field [parent=#global] # kCCMenuStateTrackingTouch

--------------------------------
-- @field [parent=#global] # kCCMenuHandlerPriority

-------------------------------
-- @field [parent=#global] CCMenu#CCMenu CCMenu preloaded module

