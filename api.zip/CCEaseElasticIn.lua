--------------------------------
-- @module CCEaseElasticIn

--------------------------------
-- @function [parent=#CCEaseElasticIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticIn] create
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return #CCEaseElasticIn

--------------------------------
-- @function [parent=#CCEaseElasticIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticIn] getPeriod
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticIn] setPeriod
-- @param self
-- @param #float fPeriod

--------------------------------
-- @function [parent=#CCEaseElasticIn] create
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return CCEaseElastic#CCEaseElastic

--------------------------------
-- @function [parent=#CCEaseElasticIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticIn] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseElasticIn] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticIn] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseElasticIn] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticIn] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticIn] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticIn] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseElasticIn] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseElasticIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticIn] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseElasticIn] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseElasticIn] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseElasticIn] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseElasticIn] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseElasticIn] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseElasticIn] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticIn] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseElasticIn] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticIn] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseElasticIn] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
