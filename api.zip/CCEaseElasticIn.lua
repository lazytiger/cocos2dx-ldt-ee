--------------------------------
-- @type CCEaseElasticIn
-- @extends CCEaseElastic#CCEaseElastic

--------------------------------
-- @function [parent=#CCEaseElasticIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return #CCEaseElasticIn

return nil
