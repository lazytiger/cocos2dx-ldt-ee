--------------------------------
-- @function [parent=#global] CCLuaLog
-- @param #char pszFormat

--------------------------------
-- @function [parent=#global] CCMessageBox
-- @param #char pszMsg
-- @param #char pszTitle

