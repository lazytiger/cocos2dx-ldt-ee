--------------------------------
-- @type CCGridAction
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCGridAction] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCGridAction] getGrid
-- @param self
-- @return CCGridBase#CCGridBase

--------------------------------
-- @function [parent=#CCGridAction] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return #CCGridAction

return nil
