-------------------------------
-- @field [parent=#global] CCRGBAProtocol#CCRGBAProtocol CCRGBAProtocol preloaded module

-------------------------------
-- @field [parent=#global] CCRGBAProtocol#CCRGBAProtocol CCRGBAProtocol preloaded module

-------------------------------
-- @field [parent=#global] CCRGBAProtocol#CCRGBAProtocol CCRGBAProtocol preloaded module

-------------------------------
-- @field [parent=#global] CCRGBAProtocol#CCRGBAProtocol CCRGBAProtocol preloaded module

