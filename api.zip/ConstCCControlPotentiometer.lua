-------------------------------
-- @field [parent=#global] CCControlPotentiometer#CCControlPotentiometer CCControlPotentiometer preloaded module

-------------------------------
-- @field [parent=#global] CCControlPotentiometer#CCControlPotentiometer CCControlPotentiometer preloaded module

-------------------------------
-- @field [parent=#global] CCControlPotentiometer#CCControlPotentiometer CCControlPotentiometer preloaded module

-------------------------------
-- @field [parent=#global] CCControlPotentiometer#CCControlPotentiometer CCControlPotentiometer preloaded module

