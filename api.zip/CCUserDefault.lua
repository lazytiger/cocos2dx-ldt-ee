--------------------------------
-- @type CCUserDefault
-- @extends #

--------------------------------
-- @function [parent=#CCUserDefault] getBoolForKey
-- @param self
-- @param #char pKey
-- @return #bool

--------------------------------
-- @function [parent=#CCUserDefault] getIntegerForKey
-- @param self
-- @param #char pKey
-- @return #int

--------------------------------
-- @function [parent=#CCUserDefault] getFloatForKey
-- @param self
-- @param #char pKey
-- @return #float

--------------------------------
-- @function [parent=#CCUserDefault] getDoubleForKey
-- @param self
-- @param #char pKey
-- @return #double

--------------------------------
-- @function [parent=#CCUserDefault] getStringForKey
-- @param self
-- @param #char pKey
-- @return #std::string

--------------------------------
-- @function [parent=#CCUserDefault] setBoolForKey
-- @param self
-- @param #char pKey
-- @param #bool value

--------------------------------
-- @function [parent=#CCUserDefault] setIntegerForKey
-- @param self
-- @param #char pKey
-- @param #int value

--------------------------------
-- @function [parent=#CCUserDefault] setFloatForKey
-- @param self
-- @param #char pKey
-- @param #float value

--------------------------------
-- @function [parent=#CCUserDefault] setDoubleForKey
-- @param self
-- @param #char pKey
-- @param #double value

--------------------------------
-- @function [parent=#CCUserDefault] setStringForKey
-- @param self
-- @param #char pKey
-- @param #std::string value

--------------------------------
-- @function [parent=#CCUserDefault] flush
-- @param self

--------------------------------
-- @function [parent=#CCUserDefault] sharedUserDefault
-- @param self
-- @return #CCUserDefault

--------------------------------
-- @function [parent=#CCUserDefault] purgeSharedUserDefault
-- @param self

--------------------------------
-- @function [parent=#CCUserDefault] getXMLFilePath
-- @param self
-- @return #std::string

return nil
