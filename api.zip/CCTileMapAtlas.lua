--------------------------------
-- @type CCTileMapAtlas
-- @extends CCAtlasNode#CCAtlasNode

--------------------------------
-- @function [parent=#CCTileMapAtlas] setTile
-- @param self
-- @param #ccColor3B tile
-- @param CCPoint#CCPoint position

--------------------------------
-- @function [parent=#CCTileMapAtlas] releaseMap
-- @param self

--------------------------------
-- @function [parent=#CCTileMapAtlas] tileAt
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCTileMapAtlas] create
-- @param self
-- @param #char tile
-- @param #char mapFile
-- @param #int tileWidth
-- @param #int tileHeight
-- @return #CCTileMapAtlas

return nil
