--------------------------------
-- @type CCEaseElastic
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseElastic] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElastic] getPeriod
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElastic] setPeriod
-- @param self
-- @param #float fPeriod

--------------------------------
-- @function [parent=#CCEaseElastic] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return #CCEaseElastic

return nil
