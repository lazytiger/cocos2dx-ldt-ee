--------------------------------
-- @field [parent=#global] # CCControlEventTouchDown

--------------------------------
-- @field [parent=#global] # CCControlEventTouchDragInside

--------------------------------
-- @field [parent=#global] # CCControlEventTouchDragOutside

--------------------------------
-- @field [parent=#global] # CCControlEventTouchDragEnter

--------------------------------
-- @field [parent=#global] # CCControlEventTouchDragExit

--------------------------------
-- @field [parent=#global] # CCControlEventTouchUpInside

--------------------------------
-- @field [parent=#global] # CCControlEventTouchUpOutside

--------------------------------
-- @field [parent=#global] # CCControlEventTouchCancel

--------------------------------
-- @field [parent=#global] # CCControlEventValueChanged

--------------------------------
-- @field [parent=#global] # CCControlStateNormal

--------------------------------
-- @field [parent=#global] # CCControlStateHighlighted

--------------------------------
-- @field [parent=#global] # CCControlStateDisabled

--------------------------------
-- @field [parent=#global] # CCControlStateSelected

-------------------------------
-- @field [parent=#global] CCControl:public#CCControl:public CCControl:public preloaded module

