--------------------------------
-- @type ccQuad2
-- @extends #

--------------------------------
-- @field [parent=#ccQuad2] #ccVertex2F tl

--------------------------------
-- @field [parent=#ccQuad2] #ccVertex2F tr

--------------------------------
-- @field [parent=#ccQuad2] #ccVertex2F bl

--------------------------------
-- @field [parent=#ccQuad2] #ccVertex2F br

return nil
