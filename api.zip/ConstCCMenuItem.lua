-------------------------------
-- @field [parent=#global] CCMenuItem#CCMenuItem CCMenuItem preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemLabel#CCMenuItemLabel CCMenuItemLabel preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemAtlasFont#CCMenuItemAtlasFont CCMenuItemAtlasFont preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemFont#CCMenuItemFont CCMenuItemFont preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemSprite#CCMenuItemSprite CCMenuItemSprite preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemImage#CCMenuItemImage CCMenuItemImage preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemToggle#CCMenuItemToggle CCMenuItemToggle preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItem#CCMenuItem CCMenuItem preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemLabel#CCMenuItemLabel CCMenuItemLabel preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemAtlasFont#CCMenuItemAtlasFont CCMenuItemAtlasFont preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemFont#CCMenuItemFont CCMenuItemFont preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemSprite#CCMenuItemSprite CCMenuItemSprite preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemImage#CCMenuItemImage CCMenuItemImage preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemToggle#CCMenuItemToggle CCMenuItemToggle preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItem#CCMenuItem CCMenuItem preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemLabel#CCMenuItemLabel CCMenuItemLabel preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemAtlasFont#CCMenuItemAtlasFont CCMenuItemAtlasFont preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemFont#CCMenuItemFont CCMenuItemFont preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemSprite#CCMenuItemSprite CCMenuItemSprite preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemImage#CCMenuItemImage CCMenuItemImage preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemToggle#CCMenuItemToggle CCMenuItemToggle preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItem#CCMenuItem CCMenuItem preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemLabel#CCMenuItemLabel CCMenuItemLabel preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemAtlasFont#CCMenuItemAtlasFont CCMenuItemAtlasFont preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemFont#CCMenuItemFont CCMenuItemFont preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemSprite#CCMenuItemSprite CCMenuItemSprite preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemImage#CCMenuItemImage CCMenuItemImage preloaded module

-------------------------------
-- @field [parent=#global] CCMenuItemToggle#CCMenuItemToggle CCMenuItemToggle preloaded module

