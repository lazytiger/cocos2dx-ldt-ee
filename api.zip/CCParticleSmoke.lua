--------------------------------
-- @type CCParticleSmoke
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleSmoke] create
-- @param self
-- @return #CCParticleSmoke

return nil
