--------------------------------
-- @module CCFadeOut

--------------------------------
-- @function [parent=#CCFadeOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeOut] create
-- @param self
-- @param #float d
-- @return #CCFadeOut

--------------------------------
-- @function [parent=#CCFadeOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFadeOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFadeOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCFadeOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFadeOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeOut] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFadeOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCFadeOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFadeOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFadeOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFadeOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFadeOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFadeOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCFadeOut] release
-- @param self

--------------------------------
-- @function [parent=#CCFadeOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCFadeOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFadeOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFadeOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCFadeOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCFadeOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
