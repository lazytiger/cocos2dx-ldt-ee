--------------------------------
-- @type CCFadeOut
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeOut] create
-- @param self
-- @param #float d
-- @return #CCFadeOut

return nil
