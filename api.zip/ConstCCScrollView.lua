--------------------------------
-- @field [parent=#global] # kCCScrollViewDirectionNone

--------------------------------
-- @field [parent=#global] # kCCScrollViewDirectionHorizontal

--------------------------------
-- @field [parent=#global] # kCCScrollViewDirectionVertical

--------------------------------
-- @field [parent=#global] # kCCScrollViewDirectionBoth

-------------------------------
-- @field [parent=#global] CCScrollView#CCScrollView CCScrollView preloaded module

