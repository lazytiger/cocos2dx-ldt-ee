-------------------------------
-- @field [parent=#global] CCTouchDispatcher#CCTouchDispatcher CCTouchDispatcher preloaded module

-------------------------------
-- @field [parent=#global] CCTouchDispatcher#CCTouchDispatcher CCTouchDispatcher preloaded module

-------------------------------
-- @field [parent=#global] CCTouchDispatcher#CCTouchDispatcher CCTouchDispatcher preloaded module

-------------------------------
-- @field [parent=#global] CCTouchDispatcher#CCTouchDispatcher CCTouchDispatcher preloaded module

