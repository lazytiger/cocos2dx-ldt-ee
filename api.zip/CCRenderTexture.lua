--------------------------------
-- @type CCRenderTexture
-- @extends CCNode#CCNode

--------------------------------
-- @function [parent=#CCRenderTexture] getSprite
-- @param self
-- @return CCSprite#CCSprite

--------------------------------
-- @function [parent=#CCRenderTexture] setSprite
-- @param self
-- @param CCSprite#CCSprite psprite

--------------------------------
-- @function [parent=#CCRenderTexture] begin
-- @param self

--------------------------------
-- @function [parent=#CCRenderTexture] endToLua
-- @param self

--------------------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param self
-- @param #float r
-- @param #float g
-- @param #float b
-- @param #float a

--------------------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param self
-- @param #float r
-- @param #float g
-- @param #float b
-- @param #float a
-- @param #float depthValue

--------------------------------
-- @function [parent=#CCRenderTexture] beginWithClear
-- @param self
-- @param #float r
-- @param #float g
-- @param #float b
-- @param #float a
-- @param #float depthValue
-- @param #int stencilValue

--------------------------------
-- @function [parent=#CCRenderTexture] clear
-- @param self
-- @param #float r
-- @param #float g
-- @param #float b
-- @param #float a

--------------------------------
-- @function [parent=#CCRenderTexture] clearDepth
-- @param self
-- @param #float depthValue

--------------------------------
-- @function [parent=#CCRenderTexture] clearStencil
-- @param self
-- @param #int stencilValue

--------------------------------
-- @function [parent=#CCRenderTexture] newCCImage
-- @param self
-- @return CCImage#CCImage

--------------------------------
-- @function [parent=#CCRenderTexture] saveToFile
-- @param self
-- @param #char szFilePath
-- @return #bool

--------------------------------
-- @function [parent=#CCRenderTexture] saveToFile
-- @param self
-- @param #char name
-- @param #tCCImageFormat format
-- @return #bool

--------------------------------
-- @function [parent=#CCRenderTexture] create
-- @param self
-- @param #int w
-- @param #int h
-- @param CCTexture2DPixelFormat#CCTexture2DPixelFormat eFormat
-- @param #GLuint uDepthStencilFormat
-- @return #CCRenderTexture

--------------------------------
-- @function [parent=#CCRenderTexture] create
-- @param self
-- @param #int w
-- @param #int h
-- @param CCTexture2DPixelFormat#CCTexture2DPixelFormat eFormat
-- @return #CCRenderTexture

--------------------------------
-- @function [parent=#CCRenderTexture] create
-- @param self
-- @param #int w
-- @param #int h
-- @return #CCRenderTexture

return nil
