--------------------------------
-- @type CCParticleFireworks
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleFireworks] create
-- @param self
-- @return #CCParticleFireworks

return nil
