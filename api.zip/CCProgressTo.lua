--------------------------------
-- @type CCProgressTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCProgressTo] create
-- @param self
-- @param #float duration
-- @param #float fPercent
-- @return #CCProgressTo

return nil
