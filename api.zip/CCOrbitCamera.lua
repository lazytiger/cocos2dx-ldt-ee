--------------------------------
-- @type CCOrbitCamera
-- @extends CCActionCamera#CCActionCamera

--------------------------------
-- @function [parent=#CCOrbitCamera] sphericalRadius
-- @param self
-- @param #float r
-- @param #float zenith
-- @param #float azimuth

--------------------------------
-- @function [parent=#CCOrbitCamera] create
-- @param self
-- @param #float t
-- @param #float radius
-- @param #float deltaRadius
-- @param #float angleZ
-- @param #float deltaAngleZ
-- @param #float angleX
-- @param #float deltaAngleX
-- @return #CCOrbitCamera

return nil
