--------------------------------
-- @type ccV3F_C4B_T2F
-- @extends #

--------------------------------
-- @field [parent=#ccV3F_C4B_T2F] #ccVertex3F vertices

--------------------------------
-- @field [parent=#ccV3F_C4B_T2F] #ccColor4B colors

--------------------------------
-- @field [parent=#ccV3F_C4B_T2F] #ccTex2F texCoords

return nil
