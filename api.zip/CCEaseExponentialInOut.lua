--------------------------------
-- @type CCEaseExponentialInOut
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseExponentialInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseExponentialInOut

return nil
