--------------------------------
-- @type CCString
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCString] intValue
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCString] uintValue
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCString] floatValue
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCString] doubleValue
-- @param self
-- @return #double

--------------------------------
-- @function [parent=#CCString] boolValue
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCString] getCString
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCString] length
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCString] compare
-- @param self
-- @param #char str
-- @return #int

--------------------------------
-- @function [parent=#CCString] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCString] create
-- @param self
-- @param #char pStr
-- @return #CCString

--------------------------------
-- @function [parent=#CCString] createWithData
-- @param self
-- @param #char pData
-- @param #long nLen
-- @return #CCString

--------------------------------
-- @function [parent=#CCString] createWithContentsOfFile
-- @param self
-- @param #char pszFileName
-- @return #CCString

return nil
