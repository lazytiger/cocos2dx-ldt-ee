--------------------------------
-- @type CCApplication
-- @extends #

--------------------------------
-- @function [parent=#CCApplication] sharedApplication
-- @param self
-- @return #CCApplication

--------------------------------
-- @function [parent=#CCApplication] getCurrentLanguage
-- @param self
-- @return #ccLanguageType

--------------------------------
-- @function [parent=#CCApplication] getTargetPlatform
-- @param self
-- @return #TargetPlatform

return nil
