--------------------------------
-- @module CCApplication

--------------------------------
-- @function [parent=#CCApplication] sharedApplication
-- @return #CCApplication

--------------------------------
-- @function [parent=#CCApplication] getCurrentLanguage
-- @param self
-- @return #ccLanguageType

--------------------------------
-- @function [parent=#CCApplication] getTargetPlatform
-- @param self
-- @return #TargetPlatform

return nil
