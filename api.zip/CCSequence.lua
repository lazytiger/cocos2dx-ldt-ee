--------------------------------
-- @type CCSequence
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSequence] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSequence] createWithTwoActions
-- @param self
-- @param CCFiniteTimeAction#CCFiniteTimeAction pActionOne
-- @param CCFiniteTimeAction#CCFiniteTimeAction pActionTwo
-- @return #CCSequence

--------------------------------
-- @function [parent=#CCSequence] create
-- @param self
-- @param CCArray#CCArray actions
-- @return #CCSequence

return nil
