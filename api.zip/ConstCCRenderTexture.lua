--------------------------------
-- @field [parent=#global] # kCCImageFormatJPEG

--------------------------------
-- @field [parent=#global] # kCCImageFormatPNG

-------------------------------
-- @field [parent=#global] CCRenderTexture#CCRenderTexture CCRenderTexture preloaded module

