-------------------------------
-- @field [parent=#global] CCCamera#CCCamera CCCamera preloaded module

-------------------------------
-- @field [parent=#global] CCCamera#CCCamera CCCamera preloaded module

-------------------------------
-- @field [parent=#global] CCCamera#CCCamera CCCamera preloaded module

-------------------------------
-- @field [parent=#global] CCCamera#CCCamera CCCamera preloaded module

