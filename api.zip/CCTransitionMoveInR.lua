--------------------------------
-- @type CCTransitionMoveInR
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionMoveInR] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionMoveInR

return nil
