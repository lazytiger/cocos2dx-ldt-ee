--------------------------------
-- @field [parent=#global] #define CCControlButtonMarginLR

--------------------------------
-- @field [parent=#global] #define CCControlButtonMarginTB

-------------------------------
-- @field [parent=#global] CCControlButton#CCControlButton CCControlButton preloaded module

