--------------------------------
-- @type CCShatteredTiles3D
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCShatteredTiles3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int nRange
-- @param #bool bShatterZ
-- @return #CCShatteredTiles3D

return nil
