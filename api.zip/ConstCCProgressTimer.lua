--------------------------------
-- @field [parent=#global] #CCProgressTimerType kCCProgressTimerTypeRadial

--------------------------------
-- @field [parent=#global] #CCProgressTimerType kCCProgressTimerTypeBar

-------------------------------
-- @field [parent=#global] CCProgressTimer#CCProgressTimer CCProgressTimer preloaded module

