--------------------------------
-- @type CCTwirl
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCTwirl] getPosition
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTwirl] setPosition
-- @param self
-- @param CCPoint#CCPoint position

--------------------------------
-- @function [parent=#CCTwirl] getAmplitude
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCTwirl] setAmplitude
-- @param self
-- @param #float fAmplitude

--------------------------------
-- @function [parent=#CCTwirl] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCTwirl] setAmplitudeRate
-- @param self
-- @param #float fAmplitudeRate

--------------------------------
-- @function [parent=#CCTwirl] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param CCPoint#CCPoint position
-- @param #int twirls
-- @param #float amplitude
-- @return #CCTwirl

return nil
