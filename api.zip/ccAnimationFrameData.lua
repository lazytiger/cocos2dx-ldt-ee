--------------------------------
-- @type ccAnimationFrameData
-- @extends #

--------------------------------
-- @field [parent=#ccAnimationFrameData] #ccT2F_Quad texCoords

--------------------------------
-- @field [parent=#ccAnimationFrameData] #float delay

--------------------------------
-- @field [parent=#ccAnimationFrameData] #CCSize size

return nil
