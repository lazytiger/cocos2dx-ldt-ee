--------------------------------
-- @type CCTransitionFadeUp
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionFadeUp] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionFadeUp

return nil
