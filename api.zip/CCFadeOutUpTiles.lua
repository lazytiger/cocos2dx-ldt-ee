--------------------------------
-- @type CCFadeOutUpTiles
-- @extends CCFadeOutTRTiles#CCFadeOutTRTiles

--------------------------------
-- @function [parent=#CCFadeOutUpTiles] transformTile
-- @param self
-- @param CCPoint#CCPoint pos
-- @param #float distance

--------------------------------
-- @function [parent=#CCFadeOutUpTiles] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return #CCFadeOutUpTiles

return nil
