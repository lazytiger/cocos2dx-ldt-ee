--------------------------------
-- @type CCParticleSun
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleSun] create
-- @param self
-- @return #CCParticleSun

return nil
