--------------------------------
-- @module ccVertex3F

--------------------------------
-- @field [parent=#ccVertex3F] #GLfloat x

--------------------------------
-- @field [parent=#ccVertex3F] #GLfloat y

--------------------------------
-- @field [parent=#ccVertex3F] #GLfloat z

return nil
