--------------------------------
-- @type ccVertex3F
-- @extends #

--------------------------------
-- @field [parent=#ccVertex3F] #GLfloat x

--------------------------------
-- @field [parent=#ccVertex3F] #GLfloat y

--------------------------------
-- @field [parent=#ccVertex3F] #GLfloat z

return nil
