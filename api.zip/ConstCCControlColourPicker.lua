-------------------------------
-- @field [parent=#global] CCControlColourPicker#CCControlColourPicker CCControlColourPicker preloaded module

-------------------------------
-- @field [parent=#global] CCControlColourPicker#CCControlColourPicker CCControlColourPicker preloaded module

-------------------------------
-- @field [parent=#global] CCControlColourPicker#CCControlColourPicker CCControlColourPicker preloaded module

-------------------------------
-- @field [parent=#global] CCControlColourPicker#CCControlColourPicker CCControlColourPicker preloaded module

