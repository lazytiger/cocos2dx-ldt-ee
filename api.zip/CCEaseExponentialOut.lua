--------------------------------
-- @type CCEaseExponentialOut
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseExponentialOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseExponentialOut

return nil
