--------------------------------
-- @module CCEaseExponentialOut

--------------------------------
-- @function [parent=#CCEaseExponentialOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseExponentialOut

--------------------------------
-- @function [parent=#CCEaseExponentialOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseExponentialOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseExponentialOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseExponentialOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseExponentialOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseExponentialOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialOut] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseExponentialOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseExponentialOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseExponentialOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseExponentialOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseExponentialOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseExponentialOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseExponentialOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseExponentialOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseExponentialOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseExponentialOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseExponentialOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseExponentialOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseExponentialOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseExponentialOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
