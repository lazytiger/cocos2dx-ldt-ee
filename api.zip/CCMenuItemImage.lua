--------------------------------
-- @type CCMenuItemImage
-- @extends CCMenuItemSprite#CCMenuItemSprite

--------------------------------
-- @function [parent=#CCMenuItemImage] setColor
-- @param self
-- @param #ccColor3B color

--------------------------------
-- @function [parent=#CCMenuItemImage] getColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCMenuItemImage] setOpacity
-- @param self
-- @param #GLubyte opacity

--------------------------------
-- @function [parent=#CCMenuItemImage] getOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCMenuItemImage] setNormalSpriteFrame
-- @param self
-- @param CCSpriteFrame#CCSpriteFrame frame

--------------------------------
-- @function [parent=#CCMenuItemImage] setSelectedSpriteFrame
-- @param self
-- @param CCSpriteFrame#CCSpriteFrame frame

--------------------------------
-- @function [parent=#CCMenuItemImage] setDisabledSpriteFrame
-- @param self
-- @param CCSpriteFrame#CCSpriteFrame frame

--------------------------------
-- @function [parent=#CCMenuItemImage] create
-- @param self
-- @param #char normalImage
-- @param #char selectedImage
-- @param #char disabledImage
-- @return #CCMenuItemImage

--------------------------------
-- @function [parent=#CCMenuItemImage] create
-- @param self
-- @param #char normalImage
-- @param #char selectedImage
-- @return #CCMenuItemImage

--------------------------------
-- @function [parent=#CCMenuItemImage] create
-- @param self
-- @return #CCMenuItemImage

return nil
