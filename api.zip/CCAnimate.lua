--------------------------------
-- @type CCAnimate
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAnimate] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAnimate] getAnimation
-- @param self
-- @return CCAnimation#CCAnimation

--------------------------------
-- @function [parent=#CCAnimate] setAnimation
-- @param self
-- @param CCAnimation#CCAnimation pAnimation

--------------------------------
-- @function [parent=#CCAnimate] create
-- @param self
-- @param CCAnimation#CCAnimation pAnimation
-- @return #CCAnimate

return nil
