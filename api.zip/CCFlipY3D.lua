--------------------------------
-- @type CCFlipY3D
-- @extends CCFlipX3D#CCFlipX3D

--------------------------------
-- @function [parent=#CCFlipY3D] create
-- @param self
-- @param #float duration
-- @return #CCFlipY3D

return nil
