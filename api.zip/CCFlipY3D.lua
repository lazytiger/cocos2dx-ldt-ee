--------------------------------
-- @module CCFlipY3D

--------------------------------
-- @function [parent=#CCFlipY3D] create
-- @param #float duration
-- @return #CCFlipY3D

--------------------------------
-- @function [parent=#CCFlipY3D] create
-- @param #float duration
-- @return CCFlipX3D#CCFlipX3D

--------------------------------
-- @function [parent=#CCFlipY3D] getGrid
-- @param self
-- @return CCGridBase#CCGridBase

--------------------------------
-- @function [parent=#CCFlipY3D] vertex
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccVertex3F

--------------------------------
-- @function [parent=#CCFlipY3D] originalVertex
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccVertex3F

--------------------------------
-- @function [parent=#CCFlipY3D] setVertex
-- @param self
-- @param CCPoint#CCPoint pos
-- @param #ccVertex3F vertex

--------------------------------
-- @function [parent=#CCFlipY3D] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFlipY3D] getGrid
-- @param self
-- @return CCGridBase#CCGridBase

--------------------------------
-- @function [parent=#CCFlipY3D] create
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return CCGridAction#CCGridAction

--------------------------------
-- @function [parent=#CCFlipY3D] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFlipY3D] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipY3D] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCFlipY3D] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFlipY3D] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFlipY3D] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFlipY3D] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFlipY3D] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCFlipY3D] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipY3D] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipY3D] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFlipY3D] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFlipY3D] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFlipY3D] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCFlipY3D] release
-- @param self

--------------------------------
-- @function [parent=#CCFlipY3D] retain
-- @param self

--------------------------------
-- @function [parent=#CCFlipY3D] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipY3D] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFlipY3D] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipY3D] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCFlipY3D] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
