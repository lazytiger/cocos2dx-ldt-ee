--------------------------------
-- @module CCEaseElasticInOut

--------------------------------
-- @function [parent=#CCEaseElasticInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return #CCEaseElasticInOut

--------------------------------
-- @function [parent=#CCEaseElasticInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticInOut] getPeriod
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticInOut] setPeriod
-- @param self
-- @param #float fPeriod

--------------------------------
-- @function [parent=#CCEaseElasticInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return CCEaseElastic#CCEaseElastic

--------------------------------
-- @function [parent=#CCEaseElasticInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseElasticInOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticInOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseElasticInOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticInOut] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticInOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticInOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseElasticInOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseElasticInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticInOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseElasticInOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseElasticInOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseElasticInOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseElasticInOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseElasticInOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseElasticInOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticInOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseElasticInOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticInOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseElasticInOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
