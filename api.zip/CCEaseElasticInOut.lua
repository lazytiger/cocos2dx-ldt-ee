--------------------------------
-- @type CCEaseElasticInOut
-- @extends CCEaseElastic#CCEaseElastic

--------------------------------
-- @function [parent=#CCEaseElasticInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return #CCEaseElasticInOut

return nil
