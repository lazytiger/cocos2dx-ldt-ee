--------------------------------
-- @type CCBezierBy
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCBezierBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCBezierBy] create
-- @param self
-- @param #float t
-- @param #ccBezierConfig c
-- @return #CCBezierBy

return nil
