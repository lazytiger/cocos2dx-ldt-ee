--------------------------------
-- @type CCPoint
-- @extends #

--------------------------------
-- @field [parent=#CCPoint] #float x

--------------------------------
-- @field [parent=#CCPoint] #float y

--------------------------------
-- @function [parent=#CCPoint] equals
-- @param self
-- @param #CCPoint target
-- @return #bool

return nil
