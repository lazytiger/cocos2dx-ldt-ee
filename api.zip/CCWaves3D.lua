--------------------------------
-- @type CCWaves3D
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCWaves3D] getAmplitude
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCWaves3D] setAmplitude
-- @param self
-- @param #float fAmplitude

--------------------------------
-- @function [parent=#CCWaves3D] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCWaves3D] setAmplitudeRate
-- @param self
-- @param #float fAmplitudeRate

--------------------------------
-- @function [parent=#CCWaves3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int waves
-- @param #float amplitude
-- @return #CCWaves3D

return nil
