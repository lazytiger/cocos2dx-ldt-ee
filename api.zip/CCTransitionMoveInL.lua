--------------------------------
-- @type CCTransitionMoveInL
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionMoveInL] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionMoveInL

return nil
