--------------------------------
-- @module CCActionInterval

--------------------------------
-- @function [parent=#CCActionInterval] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionInterval] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInterval] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCActionInterval] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionInterval] reverse
-- @param self
-- @return #CCActionInterval

--------------------------------
-- @function [parent=#CCActionInterval] create
-- @param #float d
-- @return #CCActionInterval

--------------------------------
-- @function [parent=#CCActionInterval] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionInterval] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCActionInterval] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCActionInterval] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInterval] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCActionInterval] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCActionInterval] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCActionInterval] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCActionInterval] release
-- @param self

--------------------------------
-- @function [parent=#CCActionInterval] retain
-- @param self

--------------------------------
-- @function [parent=#CCActionInterval] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInterval] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCActionInterval] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInterval] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCActionInterval] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
