--------------------------------
-- @type CCActionInterval
-- @extends CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCActionInterval] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionInterval] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInterval] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCActionInterval] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionInterval] reverse
-- @param self
-- @return #CCActionInterval

--------------------------------
-- @function [parent=#CCActionInterval] create
-- @param self
-- @param #float d
-- @return #CCActionInterval

return nil
