--------------------------------
-- @field [parent=#global] #ccTouchesMode kCCTouchesAllAtOnce

--------------------------------
-- @field [parent=#global] #ccTouchesMode kCCTouchesOneByOne

-------------------------------
-- @field [parent=#global] CCLayer#CCLayer CCLayer preloaded module

-------------------------------
-- @field [parent=#global] CCLayerRGBA#CCLayerRGBA CCLayerRGBA preloaded module

-------------------------------
-- @field [parent=#global] CCLayerColor#CCLayerColor CCLayerColor preloaded module

-------------------------------
-- @field [parent=#global] CCLayerGradient#CCLayerGradient CCLayerGradient preloaded module

-------------------------------
-- @field [parent=#global] CCLayerMultiplex#CCLayerMultiplex CCLayerMultiplex preloaded module

