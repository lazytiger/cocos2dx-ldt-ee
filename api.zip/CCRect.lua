--------------------------------
-- @module CCRect

--------------------------------
-- @field [parent=#CCRect] #CCPoint origin

--------------------------------
-- @field [parent=#CCRect] #CCSize size

--------------------------------
-- @function [parent=#CCRect] getMinX
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRect] getMidX
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRect] getMaxX
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRect] getMinY
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRect] getMidY
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRect] getMaxY
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRect] equals
-- @param self
-- @param #CCRect rect
-- @return #bool

--------------------------------
-- @function [parent=#CCRect] containsPoint
-- @param self
-- @param CCPoint#CCPoint point
-- @return #bool

--------------------------------
-- @function [parent=#CCRect] intersectsRect
-- @param self
-- @param #CCRect rect
-- @return #bool

return nil
