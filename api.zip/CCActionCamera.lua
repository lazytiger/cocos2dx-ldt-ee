--------------------------------
-- @type CCActionCamera
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCActionCamera] startWithTarget
-- @param self
-- @param CCNode#CCNode pTarget

--------------------------------
-- @function [parent=#CCActionCamera] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

return nil
