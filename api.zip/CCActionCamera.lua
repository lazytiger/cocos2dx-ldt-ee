--------------------------------
-- @module CCActionCamera

--------------------------------
-- @function [parent=#CCActionCamera] startWithTarget
-- @param self
-- @param CCNode#CCNode pTarget

--------------------------------
-- @function [parent=#CCActionCamera] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCActionCamera] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionCamera] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionCamera] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCActionCamera] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionCamera] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCActionCamera] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCActionCamera] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionCamera] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCActionCamera] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCActionCamera] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionCamera] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCActionCamera] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCActionCamera] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCActionCamera] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCActionCamera] release
-- @param self

--------------------------------
-- @function [parent=#CCActionCamera] retain
-- @param self

--------------------------------
-- @function [parent=#CCActionCamera] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionCamera] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCActionCamera] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCActionCamera] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCActionCamera] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
