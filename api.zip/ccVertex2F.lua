--------------------------------
-- @type ccVertex2F
-- @extends #

--------------------------------
-- @field [parent=#ccVertex2F] #GLfloat x

--------------------------------
-- @field [parent=#ccVertex2F] #GLfloat y

return nil
