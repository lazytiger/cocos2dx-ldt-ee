--------------------------------
-- @module ccVertex2F

--------------------------------
-- @field [parent=#ccVertex2F] #GLfloat x

--------------------------------
-- @field [parent=#ccVertex2F] #GLfloat y

return nil
