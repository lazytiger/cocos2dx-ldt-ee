--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageEnglish

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageChinese

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageFrench

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageItalian

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageGerman

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageSpanish

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageRussian

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageKorean

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageJapanese

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageHungarian

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguagePortuguese

--------------------------------
-- @field [parent=#global] #ccLanguageType kLanguageArabic

--------------------------------
-- @field [parent=#global] # kTargetWindows

--------------------------------
-- @field [parent=#global] # kTargetLinux

--------------------------------
-- @field [parent=#global] # kTargetMacOS

--------------------------------
-- @field [parent=#global] # kTargetAndroid

--------------------------------
-- @field [parent=#global] # kTargetIphone

--------------------------------
-- @field [parent=#global] # kTargetIpad

--------------------------------
-- @field [parent=#global] # kTargetBlackBerry

-------------------------------
-- @field [parent=#global] CCApplication#CCApplication CCApplication preloaded module

