-------------------------------
-- @field [parent=#global] CCTextureCache#CCTextureCache CCTextureCache preloaded module

-------------------------------
-- @field [parent=#global] CCTextureCache#CCTextureCache CCTextureCache preloaded module

-------------------------------
-- @field [parent=#global] CCTextureCache#CCTextureCache CCTextureCache preloaded module

-------------------------------
-- @field [parent=#global] CCTextureCache#CCTextureCache CCTextureCache preloaded module

