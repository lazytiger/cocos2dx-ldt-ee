--------------------------------
-- @type CCTransitionProgressOutIn
-- @extends CCTransitionProgress#CCTransitionProgress

--------------------------------
-- @function [parent=#CCTransitionProgressOutIn] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionProgressOutIn

return nil
