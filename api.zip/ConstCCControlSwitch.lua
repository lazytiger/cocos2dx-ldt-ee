-------------------------------
-- @field [parent=#global] CCControlSwitch#CCControlSwitch CCControlSwitch preloaded module

-------------------------------
-- @field [parent=#global] CCControlSwitch#CCControlSwitch CCControlSwitch preloaded module

-------------------------------
-- @field [parent=#global] CCControlSwitch#CCControlSwitch CCControlSwitch preloaded module

-------------------------------
-- @field [parent=#global] CCControlSwitch#CCControlSwitch CCControlSwitch preloaded module

