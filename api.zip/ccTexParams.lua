--------------------------------
-- @module ccTexParams

--------------------------------
-- @field [parent=#ccTexParams] #GLuint minFilter

--------------------------------
-- @field [parent=#ccTexParams] #GLuint magFilter

--------------------------------
-- @field [parent=#ccTexParams] #GLuint wrapS

--------------------------------
-- @field [parent=#ccTexParams] #GLuint wrapT

return nil
