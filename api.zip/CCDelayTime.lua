--------------------------------
-- @module CCDelayTime

--------------------------------
-- @function [parent=#CCDelayTime] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDelayTime] create
-- @param self
-- @param #float d
-- @return #CCDelayTime

--------------------------------
-- @function [parent=#CCDelayTime] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCDelayTime] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCDelayTime] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCDelayTime] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCDelayTime] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDelayTime] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDelayTime] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCDelayTime] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCDelayTime] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCDelayTime] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCDelayTime] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCDelayTime] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCDelayTime] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCDelayTime] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCDelayTime] release
-- @param self

--------------------------------
-- @function [parent=#CCDelayTime] retain
-- @param self

--------------------------------
-- @function [parent=#CCDelayTime] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCDelayTime] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCDelayTime] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCDelayTime] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCDelayTime] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
