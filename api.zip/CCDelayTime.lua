--------------------------------
-- @type CCDelayTime
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDelayTime] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDelayTime] create
-- @param self
-- @param #float d
-- @return #CCDelayTime

return nil
