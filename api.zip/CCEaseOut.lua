--------------------------------
-- @module CCEaseOut

--------------------------------
-- @function [parent=#CCEaseOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCEaseOut

--------------------------------
-- @function [parent=#CCEaseOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return CCEaseRateAction#CCEaseRateAction

--------------------------------
-- @function [parent=#CCEaseOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseOut] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
