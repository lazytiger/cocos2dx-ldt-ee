--------------------------------
-- @type CCEaseOut
-- @extends CCEaseRateAction#CCEaseRateAction

--------------------------------
-- @function [parent=#CCEaseOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCEaseOut

return nil
