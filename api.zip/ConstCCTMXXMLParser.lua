--------------------------------
-- @field [parent=#global] # TMXLayerAttribNone

--------------------------------
-- @field [parent=#global] # TMXLayerAttribBase64

--------------------------------
-- @field [parent=#global] # TMXLayerAttribGzip

--------------------------------
-- @field [parent=#global] # TMXLayerAttribZlib

--------------------------------
-- @field [parent=#global] # TMXPropertyNone

--------------------------------
-- @field [parent=#global] # TMXPropertyMap

--------------------------------
-- @field [parent=#global] # TMXPropertyLayer

--------------------------------
-- @field [parent=#global] # TMXPropertyObjectGroup

--------------------------------
-- @field [parent=#global] # TMXPropertyObject

--------------------------------
-- @field [parent=#global] # TMXPropertyTile

--------------------------------
-- @field [parent=#global] #ccTMXTileFlags kCCTMXTileHorizontalFlag

--------------------------------
-- @field [parent=#global] #ccTMXTileFlags kCCTMXTileVerticalFlag

--------------------------------
-- @field [parent=#global] #ccTMXTileFlags kCCTMXTileDiagonalFlag

--------------------------------
-- @field [parent=#global] #ccTMXTileFlags kCCFlipedAll

--------------------------------
-- @field [parent=#global] #ccTMXTileFlags kCCFlippedMask

-------------------------------
-- @field [parent=#global] CCTMXLayerInfo#CCTMXLayerInfo CCTMXLayerInfo preloaded module

-------------------------------
-- @field [parent=#global] CCTMXTilesetInfo#CCTMXTilesetInfo CCTMXTilesetInfo preloaded module

-------------------------------
-- @field [parent=#global] CCTMXMapInfo#CCTMXMapInfo CCTMXMapInfo preloaded module

