--------------------------------
-- @type CCDeccelAmplitude
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDeccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDeccelAmplitude] getRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCDeccelAmplitude] setRate
-- @param self
-- @param #float fRate

--------------------------------
-- @function [parent=#CCDeccelAmplitude] create
-- @param self
-- @param CCAction#CCAction pAction
-- @param #float duration
-- @return #CCDeccelAmplitude

return nil
