--------------------------------
-- @module CCDeccelAmplitude

--------------------------------
-- @function [parent=#CCDeccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDeccelAmplitude] getRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCDeccelAmplitude] setRate
-- @param self
-- @param #float fRate

--------------------------------
-- @function [parent=#CCDeccelAmplitude] create
-- @param self
-- @param CCAction#CCAction pAction
-- @param #float duration
-- @return #CCDeccelAmplitude

--------------------------------
-- @function [parent=#CCDeccelAmplitude] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCDeccelAmplitude] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCDeccelAmplitude] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCDeccelAmplitude] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCDeccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDeccelAmplitude] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCDeccelAmplitude] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCDeccelAmplitude] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCDeccelAmplitude] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCDeccelAmplitude] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCDeccelAmplitude] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCDeccelAmplitude] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCDeccelAmplitude] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCDeccelAmplitude] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCDeccelAmplitude] release
-- @param self

--------------------------------
-- @function [parent=#CCDeccelAmplitude] retain
-- @param self

--------------------------------
-- @function [parent=#CCDeccelAmplitude] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCDeccelAmplitude] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCDeccelAmplitude] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCDeccelAmplitude] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCDeccelAmplitude] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
