--------------------------------
-- @type CCLayerMultiplex
-- @extends CCLayer#CCLayer

--------------------------------
-- @function [parent=#CCLayerMultiplex] addLayer
-- @param self
-- @param CCLayer#CCLayer layer

--------------------------------
-- @function [parent=#CCLayerMultiplex] switchTo
-- @param self
-- @param #int n

--------------------------------
-- @function [parent=#CCLayerMultiplex] switchToAndReleaseMe
-- @param self
-- @param #int n

--------------------------------
-- @function [parent=#CCLayerMultiplex] createWithArray
-- @param self
-- @param CCArray#CCArray arrayOfLayers
-- @return #CCLayerMultiplex

--------------------------------
-- @function [parent=#CCLayerMultiplex] create
-- @param self
-- @return #CCLayerMultiplex

--------------------------------
-- @function [parent=#CCLayerMultiplex] createWithLayer
-- @param self
-- @param CCLayer#CCLayer layer
-- @return #CCLayerMultiplex

return nil
