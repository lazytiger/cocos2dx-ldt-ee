--------------------------------
-- @type CCTransitionMoveInB
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionMoveInB] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionMoveInB

return nil
