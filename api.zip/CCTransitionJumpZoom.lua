--------------------------------
-- @type CCTransitionJumpZoom
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionJumpZoom] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionJumpZoom

return nil
