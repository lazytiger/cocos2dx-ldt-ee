-------------------------------
-- @field [parent=#global] CCInteger#CCInteger CCInteger preloaded module

-------------------------------
-- @field [parent=#global] CCInteger#CCInteger CCInteger preloaded module

-------------------------------
-- @field [parent=#global] CCInteger#CCInteger CCInteger preloaded module

-------------------------------
-- @field [parent=#global] CCInteger#CCInteger CCInteger preloaded module

