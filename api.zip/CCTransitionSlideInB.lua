--------------------------------
-- @type CCTransitionSlideInB
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionSlideInB] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionSlideInB

return nil
