--------------------------------
-- @type CCLabelBMFont
-- @extends CCSpriteBatchNode#CCSpriteBatchNode

--------------------------------
-- @function [parent=#CCLabelBMFont] init
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLabelBMFont] setString
-- @param self
-- @param #char label

--------------------------------
-- @function [parent=#CCLabelBMFont] setString
-- @param self
-- @param #char label
-- @param #bool fromUpdate

--------------------------------
-- @function [parent=#CCLabelBMFont] setCString
-- @param self
-- @param #char label

--------------------------------
-- @function [parent=#CCLabelBMFont] getString
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCLabelBMFont] setAnchorPoint
-- @param self
-- @param CCPoint#CCPoint var

--------------------------------
-- @function [parent=#CCLabelBMFont] setAlignment
-- @param self
-- @param CCTextAlignment#CCTextAlignment alignment

--------------------------------
-- @function [parent=#CCLabelBMFont] setWidth
-- @param self
-- @param #float width

--------------------------------
-- @function [parent=#CCLabelBMFont] setLineBreakWithoutSpace
-- @param self
-- @param #bool breakWithoutSpace

--------------------------------
-- @function [parent=#CCLabelBMFont] setScale
-- @param self
-- @param #float scale

--------------------------------
-- @function [parent=#CCLabelBMFont] setScaleX
-- @param self
-- @param #float scaleX

--------------------------------
-- @function [parent=#CCLabelBMFont] setScaleY
-- @param self
-- @param #float scaleY

--------------------------------
-- @function [parent=#CCLabelBMFont] setFntFile
-- @param self
-- @param #char fntFile

--------------------------------
-- @function [parent=#CCLabelBMFont] getFntFile
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCLabelBMFont] setColor
-- @param self
-- @param #ccColor3B color

--------------------------------
-- @function [parent=#CCLabelBMFont] getColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCLabelBMFont] getOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCLabelBMFont] setOpacity
-- @param self
-- @param #GLubyte opacity

--------------------------------
-- @function [parent=#CCLabelBMFont] isOpacityModifyRGB
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLabelBMFont] setOpacityModifyRGB
-- @param self
-- @param #bool isOpacityModifyRGB

--------------------------------
-- @function [parent=#CCLabelBMFont] purgeCachedData
-- @param self

--------------------------------
-- @function [parent=#CCLabelBMFont] create
-- @param self
-- @param #char str
-- @param #char fntFile
-- @param #float width
-- @param CCTextAlignment#CCTextAlignment alignment
-- @param CCPoint#CCPoint imageOffset
-- @return #CCLabelBMFont

--------------------------------
-- @function [parent=#CCLabelBMFont] create
-- @param self
-- @return #CCLabelBMFont

return nil
