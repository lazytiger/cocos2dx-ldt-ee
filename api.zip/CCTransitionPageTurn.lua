--------------------------------
-- @type CCTransitionPageTurn
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionPageTurn] actionWithSize
-- @param self
-- @param CCSize#CCSize vector
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCTransitionPageTurn] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @param #bool backwards
-- @return #CCTransitionPageTurn

return nil
