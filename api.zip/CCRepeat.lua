--------------------------------
-- @type CCRepeat
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeat] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeat] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeat] create
-- @param self
-- @param CCFiniteTimeAction#CCFiniteTimeAction pAction
-- @param #int times
-- @return #CCRepeat

return nil
