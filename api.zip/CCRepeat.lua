--------------------------------
-- @module CCRepeat

--------------------------------
-- @function [parent=#CCRepeat] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeat] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeat] create
-- @param CCFiniteTimeAction#CCFiniteTimeAction pAction
-- @param #int times
-- @return #CCRepeat

--------------------------------
-- @function [parent=#CCRepeat] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRepeat] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeat] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCRepeat] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRepeat] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeat] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeat] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRepeat] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCRepeat] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCRepeat] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeat] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCRepeat] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCRepeat] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCRepeat] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCRepeat] release
-- @param self

--------------------------------
-- @function [parent=#CCRepeat] retain
-- @param self

--------------------------------
-- @function [parent=#CCRepeat] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeat] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCRepeat] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeat] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCRepeat] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
