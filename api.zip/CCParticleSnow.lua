--------------------------------
-- @type CCParticleSnow
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleSnow] create
-- @param self
-- @return #CCParticleSnow

return nil
