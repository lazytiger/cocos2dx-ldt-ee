--------------------------------
-- @field [parent=#global] # kCCControlStepperPartMinus

--------------------------------
-- @field [parent=#global] # kCCControlStepperPartPlus

--------------------------------
-- @field [parent=#global] # kCCControlStepperPartNone

-------------------------------
-- @field [parent=#global] CCControlStepper#CCControlStepper CCControlStepper preloaded module

