--------------------------------
-- @type CCPageTurn3D
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCPageTurn3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return #CCPageTurn3D

return nil
