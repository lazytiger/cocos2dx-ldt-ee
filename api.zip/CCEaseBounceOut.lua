--------------------------------
-- @type CCEaseBounceOut
-- @extends CCEaseBounce#CCEaseBounce

--------------------------------
-- @function [parent=#CCEaseBounceOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBounceOut

return nil
