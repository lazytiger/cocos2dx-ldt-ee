--------------------------------
-- @module CCEaseBounceOut

--------------------------------
-- @function [parent=#CCEaseBounceOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBounceOut

--------------------------------
-- @function [parent=#CCEaseBounceOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCEaseBounce#CCEaseBounce

--------------------------------
-- @function [parent=#CCEaseBounceOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBounceOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseBounceOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceOut] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseBounceOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseBounceOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBounceOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBounceOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBounceOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseBounceOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseBounceOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseBounceOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBounceOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseBounceOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
