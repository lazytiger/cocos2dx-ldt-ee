--------------------------------
-- @type CCTransitionCrossFade
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionCrossFade] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionCrossFade

return nil
