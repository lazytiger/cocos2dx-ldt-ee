--------------------------------
-- @field [parent=#global] # kResolutionExactFit

--------------------------------
-- @field [parent=#global] # kResolutionNoBorder

--------------------------------
-- @field [parent=#global] # kResolutionShowAll

--------------------------------
-- @field [parent=#global] # kResolutionUnKnown

-------------------------------
-- @field [parent=#global] CCEGLViewProtocol#CCEGLViewProtocol CCEGLViewProtocol preloaded module

-------------------------------
-- @field [parent=#global] CCEGLView#CCEGLView CCEGLView preloaded module

