--------------------------------
-- @module CCEaseElasticOut

--------------------------------
-- @function [parent=#CCEaseElasticOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return #CCEaseElasticOut

--------------------------------
-- @function [parent=#CCEaseElasticOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticOut] getPeriod
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticOut] setPeriod
-- @param self
-- @param #float fPeriod

--------------------------------
-- @function [parent=#CCEaseElasticOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return CCEaseElastic#CCEaseElastic

--------------------------------
-- @function [parent=#CCEaseElasticOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseElasticOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseElasticOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticOut] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseElasticOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseElasticOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseElasticOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseElasticOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseElasticOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseElasticOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseElasticOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseElasticOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseElasticOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseElasticOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseElasticOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseElasticOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
