--------------------------------
-- @type CCEaseElasticOut
-- @extends CCEaseElastic#CCEaseElastic

--------------------------------
-- @function [parent=#CCEaseElasticOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseElasticOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fPeriod
-- @return #CCEaseElasticOut

return nil
