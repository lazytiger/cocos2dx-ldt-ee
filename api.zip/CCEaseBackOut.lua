--------------------------------
-- @type CCEaseBackOut
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBackOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBackOut

return nil
