--------------------------------
-- @module CCEaseBackOut

--------------------------------
-- @function [parent=#CCEaseBackOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBackOut

--------------------------------
-- @function [parent=#CCEaseBackOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBackOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseBackOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackOut] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseBackOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseBackOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBackOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBackOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBackOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseBackOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseBackOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseBackOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBackOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseBackOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
