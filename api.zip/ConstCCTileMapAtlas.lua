-------------------------------
-- @field [parent=#global] CCTileMapAtlas#CCTileMapAtlas CCTileMapAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCTileMapAtlas#CCTileMapAtlas CCTileMapAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCTileMapAtlas#CCTileMapAtlas CCTileMapAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCTileMapAtlas#CCTileMapAtlas CCTileMapAtlas preloaded module

