--------------------------------
-- @type CCTransitionFlipY
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionFlipY] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene s
-- @param #tOrientation o
-- @return #CCTransitionFlipY

return nil
