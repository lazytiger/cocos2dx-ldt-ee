--------------------------------
-- @type CCTransitionFadeDown
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionFadeDown] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionFadeDown

return nil
