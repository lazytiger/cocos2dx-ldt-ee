--------------------------------
-- @type CCToggleVisibility
-- @extends CCActionInstant#CCActionInstant

--------------------------------
-- @function [parent=#CCToggleVisibility] create
-- @param self
-- @return #CCToggleVisibility

return nil
