--------------------------------
-- @module CCToggleVisibility

--------------------------------
-- @function [parent=#CCToggleVisibility] create
-- @return #CCToggleVisibility

--------------------------------
-- @function [parent=#CCToggleVisibility] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCToggleVisibility] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCToggleVisibility] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCToggleVisibility] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCToggleVisibility] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCToggleVisibility] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCToggleVisibility] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCToggleVisibility] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCToggleVisibility] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCToggleVisibility] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCToggleVisibility] release
-- @param self

--------------------------------
-- @function [parent=#CCToggleVisibility] retain
-- @param self

--------------------------------
-- @function [parent=#CCToggleVisibility] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCToggleVisibility] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCToggleVisibility] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCToggleVisibility] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCToggleVisibility] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
