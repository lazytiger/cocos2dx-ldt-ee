--------------------------------
-- @type CCTransitionProgress
-- @extends CCTransitionScene#CCTransitionScene

--------------------------------
-- @function [parent=#CCTransitionProgress] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionProgress

return nil
