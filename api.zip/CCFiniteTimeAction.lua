--------------------------------
-- @type CCFiniteTimeAction
-- @extends CCAction#CCAction

--------------------------------
-- @function [parent=#CCFiniteTimeAction] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFiniteTimeAction] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCFiniteTimeAction] reverse
-- @param self
-- @return #CCFiniteTimeAction

return nil
