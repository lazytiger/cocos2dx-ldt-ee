--------------------------------
-- @module CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFiniteTimeAction] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFiniteTimeAction] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCFiniteTimeAction] reverse
-- @param self
-- @return #CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFiniteTimeAction] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFiniteTimeAction] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFiniteTimeAction] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFiniteTimeAction] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFiniteTimeAction] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCFiniteTimeAction] release
-- @param self

--------------------------------
-- @function [parent=#CCFiniteTimeAction] retain
-- @param self

--------------------------------
-- @function [parent=#CCFiniteTimeAction] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFiniteTimeAction] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFiniteTimeAction] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCFiniteTimeAction] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCFiniteTimeAction] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
