--------------------------------
-- @type ccQuad3
-- @extends #

--------------------------------
-- @field [parent=#ccQuad3] #ccVertex3F bl

--------------------------------
-- @field [parent=#ccQuad3] #ccVertex3F br

--------------------------------
-- @field [parent=#ccQuad3] #ccVertex3F tl

--------------------------------
-- @field [parent=#ccQuad3] #ccVertex3F tr

return nil
