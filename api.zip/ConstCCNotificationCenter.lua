-------------------------------
-- @field [parent=#global] CCNotificationCenter#CCNotificationCenter CCNotificationCenter preloaded module

-------------------------------
-- @field [parent=#global] CCNotificationCenter#CCNotificationCenter CCNotificationCenter preloaded module

-------------------------------
-- @field [parent=#global] CCNotificationCenter#CCNotificationCenter CCNotificationCenter preloaded module

-------------------------------
-- @field [parent=#global] CCNotificationCenter#CCNotificationCenter CCNotificationCenter preloaded module

