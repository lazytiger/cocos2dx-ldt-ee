--------------------------------
-- @type CCMoveTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCMoveTo] create
-- @param self
-- @param #float duration
-- @param CCPoint#CCPoint position
-- @return #CCMoveTo

return nil
