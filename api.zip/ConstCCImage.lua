-------------------------------
-- @field [parent=#global] CCImage#CCImage CCImage preloaded module

-------------------------------
-- @field [parent=#global] CCImage#CCImage CCImage preloaded module

-------------------------------
-- @field [parent=#global] CCImage#CCImage CCImage preloaded module

-------------------------------
-- @field [parent=#global] CCImage#CCImage CCImage preloaded module

