--------------------------------
-- @module CCTimer

--------------------------------
-- @function [parent=#CCTimer] getInterval
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCTimer] setInterval
-- @param self
-- @param #float fInterval

--------------------------------
-- @function [parent=#CCTimer] update
-- @param self
-- @param #float dt

--------------------------------
-- @function [parent=#CCTimer] timerWithScriptHandler
-- @param #LUA_FUNCTION funcID
-- @param #float fSeconds
-- @return #CCTimer

--------------------------------
-- @function [parent=#CCTimer] release
-- @param self

--------------------------------
-- @function [parent=#CCTimer] retain
-- @param self

--------------------------------
-- @function [parent=#CCTimer] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTimer] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTimer] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCTimer] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCTimer] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
