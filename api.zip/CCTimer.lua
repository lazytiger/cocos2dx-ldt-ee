--------------------------------
-- @type CCTimer
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCTimer] getInterval
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCTimer] setInterval
-- @param self
-- @param #float fInterval

--------------------------------
-- @function [parent=#CCTimer] update
-- @param self
-- @param #float dt

--------------------------------
-- @function [parent=#CCTimer] timerWithScriptHandler
-- @param self
-- @param #LUA_FUNCTION funcID
-- @param #float fSeconds
-- @return #CCTimer

return nil
