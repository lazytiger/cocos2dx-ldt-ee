--------------------------------
-- @type CCParticleGalaxy
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleGalaxy] create
-- @param self
-- @return #CCParticleGalaxy

return nil
