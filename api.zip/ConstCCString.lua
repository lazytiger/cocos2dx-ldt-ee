-------------------------------
-- @field [parent=#global] CCString#CCString CCString preloaded module

-------------------------------
-- @field [parent=#global] CCString#CCString CCString preloaded module

-------------------------------
-- @field [parent=#global] CCString#CCString CCString preloaded module

-------------------------------
-- @field [parent=#global] CCString#CCString CCString preloaded module

