--------------------------------
-- @type CCEaseSineOut
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseSineOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseSineOut

return nil
