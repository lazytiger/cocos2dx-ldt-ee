--------------------------------
-- @module CCEaseSineOut

--------------------------------
-- @function [parent=#CCEaseSineOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseSineOut

--------------------------------
-- @function [parent=#CCEaseSineOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseSineOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseSineOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseSineOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseSineOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseSineOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineOut] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseSineOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseSineOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseSineOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseSineOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseSineOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseSineOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseSineOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseSineOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseSineOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseSineOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseSineOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseSineOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseSineOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseSineOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
