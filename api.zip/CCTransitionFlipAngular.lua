--------------------------------
-- @type CCTransitionFlipAngular
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionFlipAngular] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene s
-- @param #tOrientation o
-- @return #CCTransitionFlipAngular

return nil
