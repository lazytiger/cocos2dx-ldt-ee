--------------------------------
-- @type CCTransitionScene
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionScene] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionScene

return nil
