-------------------------------
-- @field [parent=#global] CCPointArray#CCPointArray CCPointArray preloaded module

-------------------------------
-- @field [parent=#global] CCCardinalSplineTo#CCCardinalSplineTo CCCardinalSplineTo preloaded module

-------------------------------
-- @field [parent=#global] CCCardinalSplineBy#CCCardinalSplineBy CCCardinalSplineBy preloaded module

-------------------------------
-- @field [parent=#global] CCCatmullRomTo#CCCatmullRomTo CCCatmullRomTo preloaded module

-------------------------------
-- @field [parent=#global] CCCatmullRomBy#CCCatmullRomBy CCCatmullRomBy preloaded module

-------------------------------
-- @field [parent=#global] CCPointArray#CCPointArray CCPointArray preloaded module

-------------------------------
-- @field [parent=#global] CCCardinalSplineTo#CCCardinalSplineTo CCCardinalSplineTo preloaded module

-------------------------------
-- @field [parent=#global] CCCardinalSplineBy#CCCardinalSplineBy CCCardinalSplineBy preloaded module

-------------------------------
-- @field [parent=#global] CCCatmullRomTo#CCCatmullRomTo CCCatmullRomTo preloaded module

-------------------------------
-- @field [parent=#global] CCCatmullRomBy#CCCatmullRomBy CCCatmullRomBy preloaded module

-------------------------------
-- @field [parent=#global] CCPointArray#CCPointArray CCPointArray preloaded module

-------------------------------
-- @field [parent=#global] CCCardinalSplineTo#CCCardinalSplineTo CCCardinalSplineTo preloaded module

-------------------------------
-- @field [parent=#global] CCCardinalSplineBy#CCCardinalSplineBy CCCardinalSplineBy preloaded module

-------------------------------
-- @field [parent=#global] CCCatmullRomTo#CCCatmullRomTo CCCatmullRomTo preloaded module

-------------------------------
-- @field [parent=#global] CCCatmullRomBy#CCCatmullRomBy CCCatmullRomBy preloaded module

-------------------------------
-- @field [parent=#global] CCPointArray#CCPointArray CCPointArray preloaded module

-------------------------------
-- @field [parent=#global] CCCardinalSplineTo#CCCardinalSplineTo CCCardinalSplineTo preloaded module

-------------------------------
-- @field [parent=#global] CCCardinalSplineBy#CCCardinalSplineBy CCCardinalSplineBy preloaded module

-------------------------------
-- @field [parent=#global] CCCatmullRomTo#CCCatmullRomTo CCCatmullRomTo preloaded module

-------------------------------
-- @field [parent=#global] CCCatmullRomBy#CCCatmullRomBy CCCatmullRomBy preloaded module

