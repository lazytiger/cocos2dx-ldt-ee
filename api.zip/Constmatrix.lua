--------------------------------
-- @function [parent=#global] kmGLFreeAll

--------------------------------
-- @function [parent=#global] kmGLPushMatrix

--------------------------------
-- @function [parent=#global] kmGLPopMatrix

--------------------------------
-- @function [parent=#global] kmGLMatrixMode
-- @param #kmGLEnum mode

--------------------------------
-- @function [parent=#global] kmGLLoadIdentity

--------------------------------
-- @function [parent=#global] kmGLLoadMatrix
-- @param #kmMat4 pIn

--------------------------------
-- @function [parent=#global] kmGLMultMatrix
-- @param #kmMat4 pIn

--------------------------------
-- @function [parent=#global] kmGLTranslatef
-- @param #float x
-- @param #float y
-- @param #float z

--------------------------------
-- @function [parent=#global] kmGLRotatef
-- @param #float angle
-- @param #float x
-- @param #float y
-- @param #float z

--------------------------------
-- @function [parent=#global] kmGLScalef
-- @param #float x
-- @param #float y
-- @param #float z

--------------------------------
-- @function [parent=#global] kmGLGetMatrix
-- @param #kmGLEnum mode
-- @param #kmMat4 pOut

-------------------------------
-- @field [parent=#global] kmMat4#kmMat4 kmMat4 preloaded module

