--------------------------------
-- @module CCScaleBy

--------------------------------
-- @function [parent=#CCScaleBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCScaleBy] create
-- @param self
-- @param #float duration
-- @param #float s
-- @return #CCScaleBy

--------------------------------
-- @function [parent=#CCScaleBy] create
-- @param self
-- @param #float duration
-- @param #float sx
-- @param #float sy
-- @return #CCScaleBy

--------------------------------
-- @function [parent=#CCScaleBy] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCScaleBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCScaleBy] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCScaleBy] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCScaleBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCScaleBy] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCScaleBy] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCScaleBy] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCScaleBy] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCScaleBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCScaleBy] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCScaleBy] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCScaleBy] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCScaleBy] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCScaleBy] release
-- @param self

--------------------------------
-- @function [parent=#CCScaleBy] retain
-- @param self

--------------------------------
-- @function [parent=#CCScaleBy] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCScaleBy] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCScaleBy] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCScaleBy] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCScaleBy] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
