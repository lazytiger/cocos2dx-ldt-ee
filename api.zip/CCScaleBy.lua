--------------------------------
-- @type CCScaleBy
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCScaleBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCScaleBy] create
-- @param self
-- @param #float duration
-- @param #float s
-- @return #CCScaleBy

--------------------------------
-- @function [parent=#CCScaleBy] create
-- @param self
-- @param #float duration
-- @param #float sx
-- @param #float sy
-- @return #CCScaleBy

return nil
