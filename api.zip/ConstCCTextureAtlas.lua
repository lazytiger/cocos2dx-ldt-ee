-------------------------------
-- @field [parent=#global] CCTextureAtlas#CCTextureAtlas CCTextureAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCTextureAtlas#CCTextureAtlas CCTextureAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCTextureAtlas#CCTextureAtlas CCTextureAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCTextureAtlas#CCTextureAtlas CCTextureAtlas preloaded module

