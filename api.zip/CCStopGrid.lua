--------------------------------
-- @module CCStopGrid

--------------------------------
-- @function [parent=#CCStopGrid] create
-- @return #CCStopGrid

--------------------------------
-- @function [parent=#CCStopGrid] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCStopGrid] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCStopGrid] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCStopGrid] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCStopGrid] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCStopGrid] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCStopGrid] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCStopGrid] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCStopGrid] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCStopGrid] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCStopGrid] release
-- @param self

--------------------------------
-- @function [parent=#CCStopGrid] retain
-- @param self

--------------------------------
-- @function [parent=#CCStopGrid] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCStopGrid] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCStopGrid] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCStopGrid] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCStopGrid] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
