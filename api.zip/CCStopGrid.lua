--------------------------------
-- @type CCStopGrid
-- @extends CCActionInstant#CCActionInstant

--------------------------------
-- @function [parent=#CCStopGrid] create
-- @param self
-- @return #CCStopGrid

return nil
