--------------------------------
-- @type CCTransitionZoomFlipX
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionZoomFlipX] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene s
-- @param #tOrientation o
-- @return #CCTransitionZoomFlipX

return nil
