--------------------------------
-- @type CCRibbon:
-- @extends CCNode#CCNode

--------------------------------
-- @function [parent=#CCRibbon:] setTexture
-- @param self
-- @param CCTexture2D#CCTexture2D val

--------------------------------
-- @function [parent=#CCRibbon:] getTexture
-- @param self
-- @return CCTexture2D#CCTexture2D

--------------------------------
-- @function [parent=#CCRibbon:] setTextureLength
-- @param self
-- @param #float val

--------------------------------
-- @function [parent=#CCRibbon:] getTextureLength
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRibbon:] setBlendFunc
-- @param self
-- @param #ccBlendFunc val

--------------------------------
-- @function [parent=#CCRibbon:] getBlendFunc
-- @param self
-- @return #ccBlendFunc

--------------------------------
-- @function [parent=#CCRibbon:] setColor
-- @param self
-- @param #ccColor4B val

--------------------------------
-- @function [parent=#CCRibbon:] getColor
-- @param self
-- @return #ccColor4B

--------------------------------
-- @function [parent=#CCRibbon:] addPointAt
-- @param self
-- @param CCPoint#CCPoint location
-- @param #float width

--------------------------------
-- @function [parent=#CCRibbon:] sideOfLine
-- @param self
-- @param CCPoint#CCPoint p
-- @param CCPoint#CCPoint l1
-- @param CCPoint#CCPoint l2
-- @return #float

--------------------------------
-- @function [parent=#CCRibbon:] create
-- @param self
-- @param #float w
-- @param #char path
-- @param #float length
-- @param #ccColor4B color
-- @param #float fade
-- @return CCRibbon#CCRibbon

return nil
