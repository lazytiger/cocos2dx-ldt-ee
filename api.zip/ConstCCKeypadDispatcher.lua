--------------------------------
-- @field [parent=#global] #ccKeypadMSGType kTypeBackClicked

--------------------------------
-- @field [parent=#global] #ccKeypadMSGType kTypeMenuClicked

