--------------------------------
-- @module CCShow

--------------------------------
-- @function [parent=#CCShow] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCShow] create
-- @return #CCShow

--------------------------------
-- @function [parent=#CCShow] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCShow] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCShow] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCShow] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCShow] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCShow] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCShow] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCShow] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCShow] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCShow] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCShow] release
-- @param self

--------------------------------
-- @function [parent=#CCShow] retain
-- @param self

--------------------------------
-- @function [parent=#CCShow] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCShow] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCShow] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCShow] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCShow] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
