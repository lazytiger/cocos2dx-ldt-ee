--------------------------------
-- @type CCShow
-- @extends CCActionInstant#CCActionInstant

--------------------------------
-- @function [parent=#CCShow] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCShow] create
-- @param self
-- @return #CCShow

return nil
