--------------------------------
-- @module CCEaseIn

--------------------------------
-- @function [parent=#CCEaseIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCEaseIn

--------------------------------
-- @function [parent=#CCEaseIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return CCEaseRateAction#CCEaseRateAction

--------------------------------
-- @function [parent=#CCEaseIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseIn] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseIn] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseIn] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseIn] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseIn] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseIn] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseIn] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseIn] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseIn] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseIn] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseIn] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseIn] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseIn] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseIn] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseIn] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseIn] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseIn] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseIn] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
