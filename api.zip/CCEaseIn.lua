--------------------------------
-- @type CCEaseIn
-- @extends CCEaseRateAction#CCEaseRateAction

--------------------------------
-- @function [parent=#CCEaseIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCEaseIn

return nil
