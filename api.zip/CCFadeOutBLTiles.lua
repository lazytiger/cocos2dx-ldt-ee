--------------------------------
-- @type CCFadeOutBLTiles
-- @extends CCFadeOutTRTiles#CCFadeOutTRTiles

--------------------------------
-- @function [parent=#CCFadeOutBLTiles] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return #CCFadeOutBLTiles

return nil
