--------------------------------
-- @type CCShakyTiles3D
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCShakyTiles3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int nRange
-- @param #bool bShakeZ
-- @return #CCShakyTiles3D

return nil
