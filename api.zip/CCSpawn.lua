--------------------------------
-- @type CCSpawn
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSpawn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSpawn] createWithTwoActions
-- @param self
-- @param CCFiniteTimeAction#CCFiniteTimeAction pAction1
-- @param CCFiniteTimeAction#CCFiniteTimeAction pAction2
-- @return #CCSpawn

--------------------------------
-- @function [parent=#CCSpawn] create
-- @param self
-- @param CCArray#CCArray actions
-- @return #CCSpawn

return nil
