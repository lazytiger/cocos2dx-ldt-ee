--------------------------------
-- @type CCTransitionSlideInL
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionSlideInL] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionSlideInL

return nil
