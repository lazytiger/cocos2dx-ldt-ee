--------------------------------
-- @type CCSplitRows
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCSplitRows] create
-- @param self
-- @param #float duration
-- @param #int nRows
-- @return #CCSplitRows

return nil
