--------------------------------
-- @module CCFlipX

--------------------------------
-- @function [parent=#CCFlipX] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipX] create
-- @param self
-- @param #bool x
-- @return #CCFlipX

--------------------------------
-- @function [parent=#CCFlipX] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipX] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipX] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFlipX] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCFlipX] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipX] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipX] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFlipX] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFlipX] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFlipX] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCFlipX] release
-- @param self

--------------------------------
-- @function [parent=#CCFlipX] retain
-- @param self

--------------------------------
-- @function [parent=#CCFlipX] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipX] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFlipX] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCFlipX] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCFlipX] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
