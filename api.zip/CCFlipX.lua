--------------------------------
-- @type CCFlipX
-- @extends CCActionInstant#CCActionInstant

--------------------------------
-- @function [parent=#CCFlipX] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFlipX] create
-- @param self
-- @param #bool x
-- @return #CCFlipX

return nil
