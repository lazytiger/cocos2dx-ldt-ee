--------------------------------
-- @type CCGrid3DAction
-- @extends CCGridAction#CCGridAction

--------------------------------
-- @function [parent=#CCGrid3DAction] getGrid
-- @param self
-- @return CCGridBase#CCGridBase

--------------------------------
-- @function [parent=#CCGrid3DAction] vertex
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccVertex3F

--------------------------------
-- @function [parent=#CCGrid3DAction] originalVertex
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #ccVertex3F

--------------------------------
-- @function [parent=#CCGrid3DAction] setVertex
-- @param self
-- @param CCPoint#CCPoint pos
-- @param #ccVertex3F vertex

return nil
