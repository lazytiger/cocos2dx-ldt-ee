--------------------------------
-- @type CCTransitionProgressRadialCCW
-- @extends CCTransitionProgress#CCTransitionProgress

--------------------------------
-- @function [parent=#CCTransitionProgressRadialCCW] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionProgressRadialCCW

return nil
