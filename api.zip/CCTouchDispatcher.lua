--------------------------------
-- @type CCTouchDispatcher
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCTouchDispatcher] isDispatchEvents
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTouchDispatcher] setDispatchEvents
-- @param self
-- @param #bool bDispatchEvents

return nil
