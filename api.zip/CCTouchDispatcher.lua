--------------------------------
-- @module CCTouchDispatcher

--------------------------------
-- @function [parent=#CCTouchDispatcher] isDispatchEvents
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTouchDispatcher] setDispatchEvents
-- @param self
-- @param #bool bDispatchEvents

--------------------------------
-- @function [parent=#CCTouchDispatcher] release
-- @param self

--------------------------------
-- @function [parent=#CCTouchDispatcher] retain
-- @param self

--------------------------------
-- @function [parent=#CCTouchDispatcher] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTouchDispatcher] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTouchDispatcher] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCTouchDispatcher] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCTouchDispatcher] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
