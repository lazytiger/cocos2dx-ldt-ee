-------------------------------
-- @field [parent=#global] CCSpriteBatchNode#CCSpriteBatchNode CCSpriteBatchNode preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteBatchNode#CCSpriteBatchNode CCSpriteBatchNode preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteBatchNode#CCSpriteBatchNode CCSpriteBatchNode preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteBatchNode#CCSpriteBatchNode CCSpriteBatchNode preloaded module

