--------------------------------
-- @type CCSet
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCSet] copy
-- @param self
-- @return #CCSet

--------------------------------
-- @function [parent=#CCSet] count
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSet] addObject
-- @param self
-- @param CCObject#CCObject pObject

--------------------------------
-- @function [parent=#CCSet] removeObject
-- @param self
-- @param CCObject#CCObject pObject

--------------------------------
-- @function [parent=#CCSet] removeAllObjects
-- @param self

--------------------------------
-- @function [parent=#CCSet] containsObject
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCSet] anyObject
-- @param self
-- @return CCObject#CCObject

return nil
