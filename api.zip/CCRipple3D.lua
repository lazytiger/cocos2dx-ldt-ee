--------------------------------
-- @type CCRipple3D
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCRipple3D] getPosition
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCRipple3D] setPosition
-- @param self
-- @param CCPoint#CCPoint position

--------------------------------
-- @function [parent=#CCRipple3D] getAmplitude
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRipple3D] setAmplitude
-- @param self
-- @param #float fAmplitude

--------------------------------
-- @function [parent=#CCRipple3D] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRipple3D] setAmplitudeRate
-- @param self
-- @param #float fAmplitudeRate

--------------------------------
-- @function [parent=#CCRipple3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param CCPoint#CCPoint position
-- @param #float radius
-- @param #int waves
-- @param #float amplitude
-- @return #CCRipple3D

return nil
