--------------------------------
-- @type CCMenu
-- @extends CCLayerRGBA#CCLayerRGBA

--------------------------------
-- @function [parent=#CCMenu] alignItemsVertically
-- @param self

--------------------------------
-- @function [parent=#CCMenu] alignItemsVerticallyWithPadding
-- @param self
-- @param #float padding

--------------------------------
-- @function [parent=#CCMenu] alignItemsHorizontally
-- @param self

--------------------------------
-- @function [parent=#CCMenu] alignItemsHorizontallyWithPadding
-- @param self
-- @param #float padding

--------------------------------
-- @function [parent=#CCMenu] alignItemsInColumnsWithArray
-- @param self
-- @param CCArray#CCArray rows

--------------------------------
-- @function [parent=#CCMenu] alignItemsInRowsWithArray
-- @param self
-- @param CCArray#CCArray columns

--------------------------------
-- @function [parent=#CCMenu] setHandlerPriority
-- @param self
-- @param #int newPriority

--------------------------------
-- @function [parent=#CCMenu] addChild
-- @param self
-- @param CCMenuItem#CCMenuItem child
-- @param #int zOrder
-- @param #int tag

--------------------------------
-- @function [parent=#CCMenu] setOpacity
-- @param self
-- @param #GLubyte opacity

--------------------------------
-- @function [parent=#CCMenu] getOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCMenu] setColor
-- @param self
-- @param #ccColor3B color

--------------------------------
-- @function [parent=#CCMenu] getColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCMenu] setOpacityModifyRGB
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCMenu] isOpacityModifyRGB
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCMenu] isEnabled
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCMenu] setEnabled
-- @param self
-- @param #bool value

--------------------------------
-- @function [parent=#CCMenu] create
-- @param self
-- @return #CCMenu

--------------------------------
-- @function [parent=#CCMenu] createWithItem
-- @param self
-- @param CCMenuItem#CCMenuItem item
-- @return #CCMenu

--------------------------------
-- @function [parent=#CCMenu] createWithArray
-- @param self
-- @param CCArray#CCArray pArrayOfItems
-- @return #CCMenu

return nil
