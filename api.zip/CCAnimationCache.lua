--------------------------------
-- @type CCAnimationCache
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCAnimationCache] addAnimation
-- @param self
-- @param CCAnimation#CCAnimation animation
-- @param #char name

--------------------------------
-- @function [parent=#CCAnimationCache] removeAnimationByName
-- @param self
-- @param #char name

--------------------------------
-- @function [parent=#CCAnimationCache] animationByName
-- @param self
-- @param #char name
-- @return CCAnimation#CCAnimation

--------------------------------
-- @function [parent=#CCAnimationCache] sharedAnimationCache
-- @param self
-- @return #CCAnimationCache

--------------------------------
-- @function [parent=#CCAnimationCache] purgeSharedAnimationCache
-- @param self

--------------------------------
-- @function [parent=#CCAnimationCache] addAnimationsWithDictionary
-- @param self
-- @param CCDictionary#CCDictionary dictionary

--------------------------------
-- @function [parent=#CCAnimationCache] addAnimationsWithFile
-- @param self
-- @param #char plist

return nil
