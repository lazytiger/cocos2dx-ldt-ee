--------------------------------
-- @type CCControlColourPicker
-- @extends CCControl#CCControl

--------------------------------
-- @function [parent=#CCControlColourPicker] setColor
-- @param self
-- @param #ccColor3B colorValue

--------------------------------
-- @function [parent=#CCControlColourPicker] setEnabled
-- @param self
-- @param #bool bEnabled

--------------------------------
-- @function [parent=#CCControlColourPicker] getcolourPicker
-- @param self
-- @return CCControlSaturationBrightnessPicker#CCControlSaturationBrightnessPicker

--------------------------------
-- @function [parent=#CCControlColourPicker] setcolourPicker
-- @param self
-- @param CCControlSaturationBrightnessPicker#CCControlSaturationBrightnessPicker var

--------------------------------
-- @function [parent=#CCControlColourPicker] getHuePicker
-- @param self
-- @return CCControlHuePicker#CCControlHuePicker

--------------------------------
-- @function [parent=#CCControlColourPicker] setHuePicker
-- @param self
-- @param CCControlHuePicker#CCControlHuePicker var

--------------------------------
-- @function [parent=#CCControlColourPicker] getBackground
-- @param self
-- @return CCSprite#CCSprite

--------------------------------
-- @function [parent=#CCControlColourPicker] setBackground
-- @param self
-- @param CCSprite#CCSprite var

--------------------------------
-- @function [parent=#CCControlColourPicker] create
-- @param self
-- @return #CCControlColourPicker

--------------------------------
-- @function [parent=#CCControlColourPicker] init
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCControlColourPicker] hueSliderValueChanged
-- @param self
-- @param CCObject#CCObject sender
-- @param CCControlEvent#CCControlEvent controlEvent

--------------------------------
-- @function [parent=#CCControlColourPicker] colourSliderValueChanged
-- @param self
-- @param CCObject#CCObject sender
-- @param CCControlEvent#CCControlEvent controlEvent

return nil
