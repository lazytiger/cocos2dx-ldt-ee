--------------------------------
-- @module CCAffineTransform

--------------------------------
-- @field [parent=#CCAffineTransform] #float a

--------------------------------
-- @field [parent=#CCAffineTransform] #float b

--------------------------------
-- @field [parent=#CCAffineTransform] #float c

--------------------------------
-- @field [parent=#CCAffineTransform] #float d

--------------------------------
-- @field [parent=#CCAffineTransform] #float tx

--------------------------------
-- @field [parent=#CCAffineTransform] #float ty

return nil
