--------------------------------
-- @type CCScene
-- @extends CCNode#CCNode

--------------------------------
-- @function [parent=#CCScene] create
-- @param self
-- @return #CCScene

return nil
