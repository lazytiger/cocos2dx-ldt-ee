-------------------------------
-- @field [parent=#global] CCScale9Sprite#CCScale9Sprite CCScale9Sprite preloaded module

-------------------------------
-- @field [parent=#global] CCScale9Sprite#CCScale9Sprite CCScale9Sprite preloaded module

-------------------------------
-- @field [parent=#global] CCScale9Sprite#CCScale9Sprite CCScale9Sprite preloaded module

-------------------------------
-- @field [parent=#global] CCScale9Sprite#CCScale9Sprite CCScale9Sprite preloaded module

