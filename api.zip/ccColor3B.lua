--------------------------------
-- @type ccColor3B
-- @extends #

--------------------------------
-- @field [parent=#ccColor3B] #GLubyte r

--------------------------------
-- @field [parent=#ccColor3B] #GLubyte g

--------------------------------
-- @field [parent=#ccColor3B] #GLubyte b

return nil
