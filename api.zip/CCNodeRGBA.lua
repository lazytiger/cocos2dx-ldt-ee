--------------------------------
-- @type CCNodeRGBA
-- @extends CCRGBAProtocol#CCRGBAProtocol

--------------------------------
-- @function [parent=#CCNodeRGBA] init
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCNodeRGBA] getOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCNodeRGBA] getDisplayedOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCNodeRGBA] setOpacity
-- @param self
-- @param #GLubyte opacity

--------------------------------
-- @function [parent=#CCNodeRGBA] updateDisplayedOpacity
-- @param self
-- @param #GLubyte parentOpacity

--------------------------------
-- @function [parent=#CCNodeRGBA] isCascadeOpacityEnabled
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCNodeRGBA] setCascadeOpacityEnabled
-- @param self
-- @param #bool cascadeOpacityEnabled

--------------------------------
-- @function [parent=#CCNodeRGBA] getColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCNodeRGBA] getDisplayedColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCNodeRGBA] setColor
-- @param self
-- @param #ccColor3B color

--------------------------------
-- @function [parent=#CCNodeRGBA] updateDisplayedColor
-- @param self
-- @param #ccColor3B parentColor

--------------------------------
-- @function [parent=#CCNodeRGBA] isCascadeColorEnabled
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCNodeRGBA] setCascadeColorEnabled
-- @param self
-- @param #bool cascadeColorEnabled

--------------------------------
-- @function [parent=#CCNodeRGBA] setOpacityModifyRGB
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCNodeRGBA] isOpacityModifyRGB
-- @param self
-- @return #bool

return nil
