--------------------------------
-- @type CCObject
-- @extends #

--------------------------------
-- @function [parent=#CCObject] release
-- @param self

--------------------------------
-- @function [parent=#CCObject] retain
-- @param self

--------------------------------
-- @function [parent=#CCObject] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCObject] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCObject] isEqual
-- @param self
-- @param #CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCObject] copy
-- @param self
-- @return #CCObject

--------------------------------
-- @function [parent=#CCObject] autorelease
-- @param self
-- @return #CCObject

return nil
