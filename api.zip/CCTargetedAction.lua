--------------------------------
-- @type CCTargetedAction
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCTargetedAction] getForcedTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCTargetedAction] setForcedTarget
-- @param self
-- @param CCNode#CCNode target

--------------------------------
-- @function [parent=#CCTargetedAction] create
-- @param self
-- @param CCNode#CCNode pTarget
-- @param CCFiniteTimeAction#CCFiniteTimeAction pAction
-- @return #CCTargetedAction

return nil
