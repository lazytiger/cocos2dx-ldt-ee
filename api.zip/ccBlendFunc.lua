--------------------------------
-- @type ccBlendFunc
-- @extends #

--------------------------------
-- @field [parent=#ccBlendFunc] #GLenum src

--------------------------------
-- @field [parent=#ccBlendFunc] #GLenum dst

return nil
