--------------------------------
-- @module CCMoveBy

--------------------------------
-- @function [parent=#CCMoveBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCMoveBy] create
-- @param self
-- @param #float duration
-- @param CCPoint#CCPoint deltaPosition
-- @return #CCMoveBy

--------------------------------
-- @function [parent=#CCMoveBy] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCMoveBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCMoveBy] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCMoveBy] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCMoveBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCMoveBy] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCMoveBy] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCMoveBy] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCMoveBy] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCMoveBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCMoveBy] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCMoveBy] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCMoveBy] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCMoveBy] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCMoveBy] release
-- @param self

--------------------------------
-- @function [parent=#CCMoveBy] retain
-- @param self

--------------------------------
-- @function [parent=#CCMoveBy] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCMoveBy] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCMoveBy] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCMoveBy] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCMoveBy] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
