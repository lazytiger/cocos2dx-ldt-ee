--------------------------------
-- @type CCMoveBy
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCMoveBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCMoveBy] create
-- @param self
-- @param #float duration
-- @param CCPoint#CCPoint deltaPosition
-- @return #CCMoveBy

return nil
