--------------------------------
-- @module CCCallFuncN

--------------------------------
-- @function [parent=#CCCallFuncN] create
-- @param #LUA_FUNCTION funcID
-- @return #CCCallFuncN

--------------------------------
-- @function [parent=#CCCallFuncN] create
-- @param #LUA_FUNCTION funcID
-- @return CCCallFunc#CCCallFunc

--------------------------------
-- @function [parent=#CCCallFuncN] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCCallFuncN] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCallFuncN] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCallFuncN] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCCallFuncN] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCCallFuncN] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCallFuncN] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCallFuncN] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCallFuncN] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCallFuncN] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCCallFuncN] release
-- @param self

--------------------------------
-- @function [parent=#CCCallFuncN] retain
-- @param self

--------------------------------
-- @function [parent=#CCCallFuncN] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCallFuncN] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCallFuncN] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCCallFuncN] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCCallFuncN] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
