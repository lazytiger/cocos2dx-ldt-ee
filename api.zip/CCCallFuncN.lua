--------------------------------
-- @type CCCallFuncN
-- @extends CCCallFunc#CCCallFunc

--------------------------------
-- @function [parent=#CCCallFuncN] create
-- @param self
-- @param #LUA_FUNCTION funcID
-- @return #CCCallFuncN

return nil
