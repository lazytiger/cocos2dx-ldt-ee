--------------------------------
-- @field [parent=#global] # kCCNodeTagInvalid

--------------------------------
-- @field [parent=#global] # kCCNodeOnEnter

--------------------------------
-- @field [parent=#global] # kCCNodeOnExit

--------------------------------
-- @field [parent=#global] #ccGLServerState CC_GL_ALL

-------------------------------
-- @field [parent=#global] CCNode#CCNode CCNode preloaded module

-------------------------------
-- @field [parent=#global] CCNodeRGBA#CCNodeRGBA CCNodeRGBA preloaded module

