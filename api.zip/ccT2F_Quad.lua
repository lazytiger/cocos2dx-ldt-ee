--------------------------------
-- @type ccT2F_Quad
-- @extends #

--------------------------------
-- @field [parent=#ccT2F_Quad] #ccTex2F bl

--------------------------------
-- @field [parent=#ccT2F_Quad] #ccTex2F br

--------------------------------
-- @field [parent=#ccT2F_Quad] #ccTex2F tl

--------------------------------
-- @field [parent=#ccT2F_Quad] #ccTex2F tr

return nil
