-------------------------------
-- @field [parent=#global] CCParallaxNode#CCParallaxNode CCParallaxNode preloaded module

-------------------------------
-- @field [parent=#global] CCParallaxNode#CCParallaxNode CCParallaxNode preloaded module

-------------------------------
-- @field [parent=#global] CCParallaxNode#CCParallaxNode CCParallaxNode preloaded module

-------------------------------
-- @field [parent=#global] CCParallaxNode#CCParallaxNode CCParallaxNode preloaded module

