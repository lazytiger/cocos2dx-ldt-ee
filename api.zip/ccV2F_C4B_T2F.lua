--------------------------------
-- @type ccV2F_C4B_T2F
-- @extends #

--------------------------------
-- @field [parent=#ccV2F_C4B_T2F] #ccVertex2F vertices

--------------------------------
-- @field [parent=#ccV2F_C4B_T2F] #ccColor4B colors

--------------------------------
-- @field [parent=#ccV2F_C4B_T2F] #ccTex2F texCoords

return nil
