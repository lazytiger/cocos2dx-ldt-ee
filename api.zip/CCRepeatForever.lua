--------------------------------
-- @module CCRepeatForever

--------------------------------
-- @function [parent=#CCRepeatForever] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeatForever] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeatForever] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCRepeatForever

--------------------------------
-- @function [parent=#CCRepeatForever] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRepeatForever] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeatForever] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCRepeatForever] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRepeatForever] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeatForever] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeatForever] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRepeatForever] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCRepeatForever] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCRepeatForever] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeatForever] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCRepeatForever] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCRepeatForever] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCRepeatForever] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCRepeatForever] release
-- @param self

--------------------------------
-- @function [parent=#CCRepeatForever] retain
-- @param self

--------------------------------
-- @function [parent=#CCRepeatForever] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeatForever] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCRepeatForever] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeatForever] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCRepeatForever] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
