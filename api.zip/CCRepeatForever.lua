--------------------------------
-- @type CCRepeatForever
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeatForever] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRepeatForever] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRepeatForever] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCRepeatForever

return nil
