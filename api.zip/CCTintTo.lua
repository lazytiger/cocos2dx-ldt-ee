--------------------------------
-- @type CCTintTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCTintTo] create
-- @param self
-- @param #float duration
-- @param #GLubyte red
-- @param #GLubyte green
-- @param #GLubyte blue
-- @return #CCTintTo

return nil
