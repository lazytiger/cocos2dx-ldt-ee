--------------------------------
-- @type CCTransitionProgressRadialCW
-- @extends CCTransitionProgress#CCTransitionProgress

--------------------------------
-- @function [parent=#CCTransitionProgressRadialCW] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionProgressRadialCW

return nil
