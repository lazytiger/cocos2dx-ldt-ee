--------------------------------
-- @type CCJumpTiles3D
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCJumpTiles3D] getAmplitude
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCJumpTiles3D] setAmplitude
-- @param self
-- @param #float fAmplitude

--------------------------------
-- @function [parent=#CCJumpTiles3D] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCJumpTiles3D] setAmplitudeRate
-- @param self
-- @param #float fAmplitudeRate

--------------------------------
-- @function [parent=#CCJumpTiles3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int numberOfJumps
-- @param #float amplitude
-- @return #CCJumpTiles3D

return nil
