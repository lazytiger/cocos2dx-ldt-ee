--------------------------------
-- @field [parent=#global] #tOrientation kCCTransitionOrientationLeftOver

--------------------------------
-- @field [parent=#global] #tOrientation kCCTransitionOrientationRightOver

--------------------------------
-- @field [parent=#global] #tOrientation kCCTransitionOrientationUpOver

--------------------------------
-- @field [parent=#global] #tOrientation kCCTransitionOrientationDownOver

-------------------------------
-- @field [parent=#global] CCTransitionScene#CCTransitionScene CCTransitionScene preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionSceneOriented#CCTransitionSceneOriented CCTransitionSceneOriented preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionRotoZoom#CCTransitionRotoZoom CCTransitionRotoZoom preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionJumpZoom#CCTransitionJumpZoom CCTransitionJumpZoom preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionMoveInL#CCTransitionMoveInL CCTransitionMoveInL preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionMoveInR#CCTransitionMoveInR CCTransitionMoveInR preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionMoveInT#CCTransitionMoveInT CCTransitionMoveInT preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionMoveInB#CCTransitionMoveInB CCTransitionMoveInB preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionSlideInL#CCTransitionSlideInL CCTransitionSlideInL preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionSlideInR#CCTransitionSlideInR CCTransitionSlideInR preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionSlideInB#CCTransitionSlideInB CCTransitionSlideInB preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionSlideInT#CCTransitionSlideInT CCTransitionSlideInT preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionShrinkGrow#CCTransitionShrinkGrow CCTransitionShrinkGrow preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionFlipX#CCTransitionFlipX CCTransitionFlipX preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionFlipY#CCTransitionFlipY CCTransitionFlipY preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionFlipAngular#CCTransitionFlipAngular CCTransitionFlipAngular preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionZoomFlipX#CCTransitionZoomFlipX CCTransitionZoomFlipX preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionZoomFlipY#CCTransitionZoomFlipY CCTransitionZoomFlipY preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionZoomFlipAngular#CCTransitionZoomFlipAngular CCTransitionZoomFlipAngular preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionFade#CCTransitionFade CCTransitionFade preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionCrossFade#CCTransitionCrossFade CCTransitionCrossFade preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionTurnOffTiles#CCTransitionTurnOffTiles CCTransitionTurnOffTiles preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionSplitCols#CCTransitionSplitCols CCTransitionSplitCols preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionSplitRows#CCTransitionSplitRows CCTransitionSplitRows preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionFadeTR#CCTransitionFadeTR CCTransitionFadeTR preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionFadeBL#CCTransitionFadeBL CCTransitionFadeBL preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionFadeUp#CCTransitionFadeUp CCTransitionFadeUp preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionFadeDown#CCTransitionFadeDown CCTransitionFadeDown preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCCW#CCTransitionProgressRadialCCW CCTransitionProgressRadialCCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCW#CCTransitionProgressRadialCW CCTransitionProgressRadialCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionPageTurn#CCTransitionPageTurn CCTransitionPageTurn preloaded module

