--------------------------------
-- @type CCRotateTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRotateTo] create
-- @param self
-- @param #float duration
-- @param #float fDeltaAngle
-- @return #CCRotateTo

return nil
