--------------------------------
-- @module CCRotateTo

--------------------------------
-- @function [parent=#CCRotateTo] create
-- @param #float duration
-- @param #float fDeltaAngle
-- @return #CCRotateTo

--------------------------------
-- @function [parent=#CCRotateTo] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRotateTo] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRotateTo] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCRotateTo] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRotateTo] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRotateTo] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCRotateTo] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCRotateTo] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCRotateTo] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCRotateTo] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRotateTo] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCRotateTo] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCRotateTo] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCRotateTo] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCRotateTo] release
-- @param self

--------------------------------
-- @function [parent=#CCRotateTo] retain
-- @param self

--------------------------------
-- @function [parent=#CCRotateTo] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCRotateTo] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCRotateTo] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCRotateTo] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCRotateTo] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
