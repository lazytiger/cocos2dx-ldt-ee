-------------------------------
-- @field [parent=#global] CCActionCamera#CCActionCamera CCActionCamera preloaded module

-------------------------------
-- @field [parent=#global] CCOrbitCamera#CCOrbitCamera CCOrbitCamera preloaded module

-------------------------------
-- @field [parent=#global] CCActionCamera#CCActionCamera CCActionCamera preloaded module

-------------------------------
-- @field [parent=#global] CCOrbitCamera#CCOrbitCamera CCOrbitCamera preloaded module

-------------------------------
-- @field [parent=#global] CCActionCamera#CCActionCamera CCActionCamera preloaded module

-------------------------------
-- @field [parent=#global] CCOrbitCamera#CCOrbitCamera CCOrbitCamera preloaded module

-------------------------------
-- @field [parent=#global] CCActionCamera#CCActionCamera CCActionCamera preloaded module

-------------------------------
-- @field [parent=#global] CCOrbitCamera#CCOrbitCamera CCOrbitCamera preloaded module

