--------------------------------
-- @type CCFadeOutDownTiles
-- @extends CCFadeOutUpTiles#CCFadeOutUpTiles

--------------------------------
-- @function [parent=#CCFadeOutDownTiles] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return #CCFadeOutDownTiles

return nil
