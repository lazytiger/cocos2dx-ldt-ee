--------------------------------
-- @field [parent=#global] # CCTMXOrientationOrtho

--------------------------------
-- @field [parent=#global] # CCTMXOrientationHex

--------------------------------
-- @field [parent=#global] # CCTMXOrientationIso

-------------------------------
-- @field [parent=#global] CCTMXTiledMap#CCTMXTiledMap CCTMXTiledMap preloaded module

