-------------------------------
-- @field [parent=#global] CCTransitionProgress#CCTransitionProgress CCTransitionProgress preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCCW#CCTransitionProgressRadialCCW CCTransitionProgressRadialCCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCW#CCTransitionProgressRadialCW CCTransitionProgressRadialCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressHorizontal#CCTransitionProgressHorizontal CCTransitionProgressHorizontal preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressVertical#CCTransitionProgressVertical CCTransitionProgressVertical preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressInOut#CCTransitionProgressInOut CCTransitionProgressInOut preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressOutIn#CCTransitionProgressOutIn CCTransitionProgressOutIn preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgress#CCTransitionProgress CCTransitionProgress preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCCW#CCTransitionProgressRadialCCW CCTransitionProgressRadialCCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCW#CCTransitionProgressRadialCW CCTransitionProgressRadialCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressHorizontal#CCTransitionProgressHorizontal CCTransitionProgressHorizontal preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressVertical#CCTransitionProgressVertical CCTransitionProgressVertical preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressInOut#CCTransitionProgressInOut CCTransitionProgressInOut preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressOutIn#CCTransitionProgressOutIn CCTransitionProgressOutIn preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgress#CCTransitionProgress CCTransitionProgress preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCCW#CCTransitionProgressRadialCCW CCTransitionProgressRadialCCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCW#CCTransitionProgressRadialCW CCTransitionProgressRadialCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressHorizontal#CCTransitionProgressHorizontal CCTransitionProgressHorizontal preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressVertical#CCTransitionProgressVertical CCTransitionProgressVertical preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressInOut#CCTransitionProgressInOut CCTransitionProgressInOut preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressOutIn#CCTransitionProgressOutIn CCTransitionProgressOutIn preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgress#CCTransitionProgress CCTransitionProgress preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCCW#CCTransitionProgressRadialCCW CCTransitionProgressRadialCCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressRadialCW#CCTransitionProgressRadialCW CCTransitionProgressRadialCW preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressHorizontal#CCTransitionProgressHorizontal CCTransitionProgressHorizontal preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressVertical#CCTransitionProgressVertical CCTransitionProgressVertical preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressInOut#CCTransitionProgressInOut CCTransitionProgressInOut preloaded module

-------------------------------
-- @field [parent=#global] CCTransitionProgressOutIn#CCTransitionProgressOutIn CCTransitionProgressOutIn preloaded module

