--------------------------------
-- @type CCEGLView
-- @extends CCEGLViewProtocol#CCEGLViewProtocol

--------------------------------
-- @function [parent=#CCEGLView] sharedOpenGLView
-- @param self
-- @return #CCEGLView

return nil
