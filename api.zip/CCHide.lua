--------------------------------
-- @module CCHide

--------------------------------
-- @function [parent=#CCHide] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCHide] create
-- @param self
-- @return #CCHide

--------------------------------
-- @function [parent=#CCHide] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCHide] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCHide] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCHide] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCHide] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCHide] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCHide] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCHide] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCHide] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCHide] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCHide] release
-- @param self

--------------------------------
-- @function [parent=#CCHide] retain
-- @param self

--------------------------------
-- @function [parent=#CCHide] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCHide] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCHide] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCHide] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCHide] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
