--------------------------------
-- @type CCHide
-- @extends CCActionInstant#CCActionInstant

--------------------------------
-- @function [parent=#CCHide] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCHide] create
-- @param self
-- @return #CCHide

return nil
