--------------------------------
-- @type CCLabelAtlas
-- @extends CCAtlasNode#CCAtlasNode

--------------------------------
-- @function [parent=#CCLabelAtlas] updateAtlasValues
-- @param self

--------------------------------
-- @function [parent=#CCLabelAtlas] setString
-- @param self
-- @param #char label

--------------------------------
-- @function [parent=#CCLabelAtlas] getString
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCLabelAtlas] getTexture
-- @param self
-- @return CCTexture2D#CCTexture2D

--------------------------------
-- @function [parent=#CCLabelAtlas] setTexture
-- @param self
-- @param CCTexture2D#CCTexture2D texture

--------------------------------
-- @function [parent=#CCLabelAtlas] create
-- @param self
-- @param #char label
-- @param #char charMapFile
-- @param #int itemWidth
-- @param #int itemHeight
-- @param #int startCharMap
-- @return #CCLabelAtlas

--------------------------------
-- @function [parent=#CCLabelAtlas] create
-- @param self
-- @param #char sring
-- @param #char fntFile
-- @return #CCLabelAtlas

return nil
