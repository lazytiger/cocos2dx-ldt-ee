--------------------------------
-- @type CCTransitionZoomFlipAngular
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionZoomFlipAngular] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene s
-- @param #tOrientation o
-- @return #CCTransitionZoomFlipAngular

return nil
