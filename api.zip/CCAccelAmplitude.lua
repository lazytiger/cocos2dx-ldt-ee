--------------------------------
-- @type CCAccelAmplitude
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelAmplitude] getRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelAmplitude] setRate
-- @param self
-- @param #float fRate

--------------------------------
-- @function [parent=#CCAccelAmplitude] create
-- @param self
-- @param CCAction#CCAction pAction
-- @param #float duration
-- @return #CCAccelAmplitude

return nil
