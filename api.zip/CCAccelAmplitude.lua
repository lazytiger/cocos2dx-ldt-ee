--------------------------------
-- @module CCAccelAmplitude

--------------------------------
-- @function [parent=#CCAccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelAmplitude] getRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelAmplitude] setRate
-- @param self
-- @param #float fRate

--------------------------------
-- @function [parent=#CCAccelAmplitude] create
-- @param CCAction#CCAction pAction
-- @param #float duration
-- @return #CCAccelAmplitude

--------------------------------
-- @function [parent=#CCAccelAmplitude] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelAmplitude] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAccelAmplitude] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCAccelAmplitude] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelAmplitude] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelAmplitude] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelAmplitude] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCAccelAmplitude] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCAccelAmplitude] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAccelAmplitude] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCAccelAmplitude] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCAccelAmplitude] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCAccelAmplitude] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCAccelAmplitude] release
-- @param self

--------------------------------
-- @function [parent=#CCAccelAmplitude] retain
-- @param self

--------------------------------
-- @function [parent=#CCAccelAmplitude] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAccelAmplitude] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCAccelAmplitude] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCAccelAmplitude] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCAccelAmplitude] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
