--------------------------------
-- @type CCJumpBy
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCJumpBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCJumpBy] create
-- @param self
-- @param #float duration
-- @param CCPoint#CCPoint position
-- @param #float height
-- @param #int jumps
-- @return #CCJumpBy

return nil
