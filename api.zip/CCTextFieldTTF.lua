--------------------------------
-- @type CCTextFieldTTF
-- @extends CCLabelTTF#CCLabelTTF

--------------------------------
-- @function [parent=#CCTextFieldTTF] attachWithIME
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTextFieldTTF] detachWithIME
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTextFieldTTF] getCharCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTextFieldTTF] setColorSpaceHolder
-- @param self
-- @param #ccColor3B val

--------------------------------
-- @function [parent=#CCTextFieldTTF] getColorSpaceHolder
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCTextFieldTTF] setString
-- @param self
-- @param #char text

--------------------------------
-- @function [parent=#CCTextFieldTTF] getString
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCTextFieldTTF] setPlaceHolder
-- @param self
-- @param #char text

--------------------------------
-- @function [parent=#CCTextFieldTTF] getPlaceHolder
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCTextFieldTTF] textFieldWithPlaceHolder
-- @param self
-- @param #char placeholder
-- @param CCSize#CCSize dimensions
-- @param CCTextAlignment#CCTextAlignment alignment
-- @param #char fontName
-- @param #float fontSize
-- @return #CCTextFieldTTF

--------------------------------
-- @function [parent=#CCTextFieldTTF] textFieldWithPlaceHolder
-- @param self
-- @param #char placeholder
-- @param #char fontName
-- @param #float fontSize
-- @return #CCTextFieldTTF

return nil
