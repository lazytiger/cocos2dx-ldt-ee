--------------------------------
-- @type CCMenuItemFont
-- @extends CCMenuItemLabel#CCMenuItemLabel

--------------------------------
-- @function [parent=#CCMenuItemFont] setFontSize
-- @param self
-- @param #int s

--------------------------------
-- @function [parent=#CCMenuItemFont] fontSize
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCMenuItemFont] setFontName
-- @param self
-- @param #char name

--------------------------------
-- @function [parent=#CCMenuItemFont] fontName
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCMenuItemFont] setFontSizeObj
-- @param self
-- @param #int s

--------------------------------
-- @function [parent=#CCMenuItemFont] fontSizeObj
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCMenuItemFont] setFontNameObj
-- @param self
-- @param #char name

--------------------------------
-- @function [parent=#CCMenuItemFont] fontNameObj
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCMenuItemFont] create
-- @param self
-- @param #char value
-- @return #CCMenuItemFont

return nil
