--------------------------------
-- @type CCJumpTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCJumpTo] create
-- @param self
-- @param #float duration
-- @param CCPoint#CCPoint position
-- @param #float height
-- @param #int jumps
-- @return #CCJumpTo

return nil
