--------------------------------
-- @type CCLayerGradient
-- @extends CCLayerColor#CCLayerColor

--------------------------------
-- @function [parent=#CCLayerGradient] setStartColor
-- @param self
-- @param #ccColor3B colors

--------------------------------
-- @function [parent=#CCLayerGradient] getStartColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCLayerGradient] setEndColor
-- @param self
-- @param #ccColor3B Value

--------------------------------
-- @function [parent=#CCLayerGradient] getEndColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCLayerGradient] setStartOpacity
-- @param self
-- @param #GLubyte Value

--------------------------------
-- @function [parent=#CCLayerGradient] getStartOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCLayerGradient] setEndOpacity
-- @param self
-- @param #GLubyte Value

--------------------------------
-- @function [parent=#CCLayerGradient] getEndOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCLayerGradient] setVector
-- @param self
-- @param CCPoint#CCPoint Value

--------------------------------
-- @function [parent=#CCLayerGradient] getVector
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCLayerGradient] setCompressedInterpolation
-- @param self
-- @param #bool Value

--------------------------------
-- @function [parent=#CCLayerGradient] isCompressedInterpolation
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLayerGradient] create
-- @param self
-- @param #ccColor4B start
-- @param #ccColor4B end
-- @param CCPoint#CCPoint v
-- @return #CCLayerGradient

--------------------------------
-- @function [parent=#CCLayerGradient] create
-- @param self
-- @param #ccColor4B start
-- @param #ccColor4B end
-- @return #CCLayerGradient

--------------------------------
-- @function [parent=#CCLayerGradient] create
-- @param self
-- @return #CCLayerGradient

return nil
