--------------------------------
-- @module CCTintBy

--------------------------------
-- @function [parent=#CCTintBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCTintBy] create
-- @param #float duration
-- @param #GLshort deltaRed
-- @param #GLshort deltaGreen
-- @param #GLshort deltaBlue
-- @return #CCTintBy

--------------------------------
-- @function [parent=#CCTintBy] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCTintBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTintBy] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCTintBy] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCTintBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCTintBy] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCTintBy] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCTintBy] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCTintBy] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCTintBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTintBy] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCTintBy] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCTintBy] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTintBy] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCTintBy] release
-- @param self

--------------------------------
-- @function [parent=#CCTintBy] retain
-- @param self

--------------------------------
-- @function [parent=#CCTintBy] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTintBy] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTintBy] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCTintBy] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCTintBy] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
