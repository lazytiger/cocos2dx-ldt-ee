--------------------------------
-- @type CCTintBy
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCTintBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCTintBy] create
-- @param self
-- @param #float duration
-- @param #GLshort deltaRed
-- @param #GLshort deltaGreen
-- @param #GLshort deltaBlue
-- @return #CCTintBy

return nil
