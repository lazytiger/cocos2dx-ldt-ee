--------------------------------
-- @type CCTransitionProgressHorizontal
-- @extends CCTransitionProgress#CCTransitionProgress

--------------------------------
-- @function [parent=#CCTransitionProgressHorizontal] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionProgressHorizontal

return nil
