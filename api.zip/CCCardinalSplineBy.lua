--------------------------------
-- @module CCCardinalSplineBy

--------------------------------
-- @function [parent=#CCCardinalSplineBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCardinalSplineBy] create
-- @param self
-- @param #float duration
-- @param CCPointArray#CCPointArray points
-- @param #float tension
-- @return #CCCardinalSplineBy

--------------------------------
-- @function [parent=#CCCardinalSplineBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCardinalSplineBy] getPoints
-- @param self
-- @return CCPointArray#CCPointArray

--------------------------------
-- @function [parent=#CCCardinalSplineBy] setPoints
-- @param self
-- @param CCPointArray#CCPointArray points

--------------------------------
-- @function [parent=#CCCardinalSplineBy] create
-- @param self
-- @param #float duration
-- @param CCPointArray#CCPointArray points
-- @param #float tension
-- @return CCCardinalSplineTo#CCCardinalSplineTo

--------------------------------
-- @function [parent=#CCCardinalSplineBy] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCardinalSplineBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCardinalSplineBy] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCCardinalSplineBy] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCardinalSplineBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCardinalSplineBy] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCardinalSplineBy] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCardinalSplineBy] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCCardinalSplineBy] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCCardinalSplineBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCardinalSplineBy] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCardinalSplineBy] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCardinalSplineBy] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCardinalSplineBy] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCCardinalSplineBy] release
-- @param self

--------------------------------
-- @function [parent=#CCCardinalSplineBy] retain
-- @param self

--------------------------------
-- @function [parent=#CCCardinalSplineBy] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCardinalSplineBy] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCardinalSplineBy] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCCardinalSplineBy] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCCardinalSplineBy] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
