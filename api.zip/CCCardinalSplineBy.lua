--------------------------------
-- @type CCCardinalSplineBy
-- @extends CCCardinalSplineTo#CCCardinalSplineTo

--------------------------------
-- @function [parent=#CCCardinalSplineBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCardinalSplineBy] create
-- @param self
-- @param #float duration
-- @param CCPointArray#CCPointArray points
-- @param #float tension
-- @return #CCCardinalSplineBy

return nil
