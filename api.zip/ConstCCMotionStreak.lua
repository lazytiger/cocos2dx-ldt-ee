-------------------------------
-- @field [parent=#global] CCMotionStreak#CCMotionStreak CCMotionStreak preloaded module

-------------------------------
-- @field [parent=#global] CCMotionStreak#CCMotionStreak CCMotionStreak preloaded module

-------------------------------
-- @field [parent=#global] CCMotionStreak#CCMotionStreak CCMotionStreak preloaded module

-------------------------------
-- @field [parent=#global] CCMotionStreak#CCMotionStreak CCMotionStreak preloaded module

