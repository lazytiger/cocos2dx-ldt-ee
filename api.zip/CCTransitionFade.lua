--------------------------------
-- @type CCTransitionFade
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionFade] create
-- @param self
-- @param #float duration
-- @param CCScene#CCScene scene
-- @param #ccColor3B color
-- @return #CCTransitionFade

return nil
