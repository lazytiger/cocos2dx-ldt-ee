--------------------------------
-- @type CCMenuItemLabel
-- @extends CCMenuItem#CCMenuItem

--------------------------------
-- @function [parent=#CCMenuItemLabel] setString
-- @param self
-- @param #char label

--------------------------------
-- @function [parent=#CCMenuItemLabel] setOpacity
-- @param self
-- @param #GLubyte opacity

--------------------------------
-- @function [parent=#CCMenuItemLabel] getOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCMenuItemLabel] setColor
-- @param self
-- @param #ccColor3B color

--------------------------------
-- @function [parent=#CCMenuItemLabel] getColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCMenuItemLabel] setDisabledColor
-- @param self
-- @param #ccColor3B color

--------------------------------
-- @function [parent=#CCMenuItemLabel] getDisabledColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCMenuItemLabel] setLabel
-- @param self
-- @param CCNode#CCNode pLabel

--------------------------------
-- @function [parent=#CCMenuItemLabel] getLabel
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCMenuItemLabel] activate
-- @param self

--------------------------------
-- @function [parent=#CCMenuItemLabel] selected
-- @param self

--------------------------------
-- @function [parent=#CCMenuItemLabel] unselected
-- @param self

--------------------------------
-- @function [parent=#CCMenuItemLabel] setEnabled
-- @param self
-- @param #bool enabled

--------------------------------
-- @function [parent=#CCMenuItemLabel] setOpacityModifyRGB
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCMenuItemLabel] isOpacityModifyRGB
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCMenuItemLabel] create
-- @param self
-- @param CCNode#CCNode label
-- @return #CCMenuItemLabel

return nil
