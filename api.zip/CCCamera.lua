--------------------------------
-- @type CCCamera
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCCamera] init
-- @param self

--------------------------------
-- @function [parent=#CCCamera] description
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCCamera] setDirty
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCCamera] isDirty
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCamera] restore
-- @param self

--------------------------------
-- @function [parent=#CCCamera] locate
-- @param self

--------------------------------
-- @function [parent=#CCCamera] setEyeXYZ
-- @param self
-- @param #float fEyeX
-- @param #float fEyeY
-- @param #float fEyeZ

--------------------------------
-- @function [parent=#CCCamera] setCenterXYZ
-- @param self
-- @param #float fCenterX
-- @param #float fCenterY
-- @param #float fCenterZ

--------------------------------
-- @function [parent=#CCCamera] setUpXYZ
-- @param self
-- @param #float fUpX
-- @param #float fUpY
-- @param #float fUpZ

--------------------------------
-- @function [parent=#CCCamera] getEyeXYZ
-- @param self
-- @param #float pEyeX
-- @param #float pEyeY
-- @param #float pEyeZ

--------------------------------
-- @function [parent=#CCCamera] getCenterXYZ
-- @param self
-- @param #float pCenterX
-- @param #float pCenterY
-- @param #float pCenterZ

--------------------------------
-- @function [parent=#CCCamera] getUpXYZ
-- @param self
-- @param #float pUpX
-- @param #float pUpY
-- @param #float pUpZ

--------------------------------
-- @function [parent=#CCCamera] getZEye
-- @param self
-- @return #float

return nil
