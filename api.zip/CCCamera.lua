--------------------------------
-- @module CCCamera

--------------------------------
-- @function [parent=#CCCamera] init
-- @param self

--------------------------------
-- @function [parent=#CCCamera] description
-- @param self
-- @return #char

--------------------------------
-- @function [parent=#CCCamera] setDirty
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCCamera] isDirty
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCamera] restore
-- @param self

--------------------------------
-- @function [parent=#CCCamera] locate
-- @param self

--------------------------------
-- @function [parent=#CCCamera] setEyeXYZ
-- @param self
-- @param #float fEyeX
-- @param #float fEyeY
-- @param #float fEyeZ

--------------------------------
-- @function [parent=#CCCamera] setCenterXYZ
-- @param self
-- @param #float fCenterX
-- @param #float fCenterY
-- @param #float fCenterZ

--------------------------------
-- @function [parent=#CCCamera] setUpXYZ
-- @param self
-- @param #float fUpX
-- @param #float fUpY
-- @param #float fUpZ

--------------------------------
-- @function [parent=#CCCamera] getEyeXYZ
-- @param self
-- @param #float pEyeX
-- @param #float pEyeY
-- @param #float pEyeZ

--------------------------------
-- @function [parent=#CCCamera] getCenterXYZ
-- @param self
-- @param #float pCenterX
-- @param #float pCenterY
-- @param #float pCenterZ

--------------------------------
-- @function [parent=#CCCamera] getUpXYZ
-- @param self
-- @param #float pUpX
-- @param #float pUpY
-- @param #float pUpZ

--------------------------------
-- @function [parent=#CCCamera] getZEye
-- @return #float

--------------------------------
-- @function [parent=#CCCamera] release
-- @param self

--------------------------------
-- @function [parent=#CCCamera] retain
-- @param self

--------------------------------
-- @function [parent=#CCCamera] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCamera] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCamera] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCCamera] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCCamera] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
