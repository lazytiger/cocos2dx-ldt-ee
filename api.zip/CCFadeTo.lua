--------------------------------
-- @type CCFadeTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeTo] create
-- @param self
-- @param #float duration
-- @param #GLubyte opacity
-- @return #CCFadeTo

return nil
