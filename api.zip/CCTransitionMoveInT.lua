--------------------------------
-- @type CCTransitionMoveInT
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionMoveInT] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionMoveInT

return nil
