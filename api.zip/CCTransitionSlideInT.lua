--------------------------------
-- @type CCTransitionSlideInT
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionSlideInT] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionSlideInT

return nil
