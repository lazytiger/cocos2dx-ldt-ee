-------------------------------
-- @field [parent=#global] CCAnimationCache#CCAnimationCache CCAnimationCache preloaded module

-------------------------------
-- @field [parent=#global] CCAnimationCache#CCAnimationCache CCAnimationCache preloaded module

-------------------------------
-- @field [parent=#global] CCAnimationCache#CCAnimationCache CCAnimationCache preloaded module

-------------------------------
-- @field [parent=#global] CCAnimationCache#CCAnimationCache CCAnimationCache preloaded module

