--------------------------------
-- @module CCCatmullRomBy

--------------------------------
-- @function [parent=#CCCatmullRomBy] create
-- @param #float dt
-- @param CCPointArray#CCPointArray points
-- @return #CCCatmullRomBy

--------------------------------
-- @function [parent=#CCCatmullRomBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCatmullRomBy] create
-- @param #float duration
-- @param CCPointArray#CCPointArray points
-- @param #float tension
-- @return CCCardinalSplineBy#CCCardinalSplineBy

--------------------------------
-- @function [parent=#CCCatmullRomBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCatmullRomBy] getPoints
-- @param self
-- @return CCPointArray#CCPointArray

--------------------------------
-- @function [parent=#CCCatmullRomBy] setPoints
-- @param self
-- @param CCPointArray#CCPointArray points

--------------------------------
-- @function [parent=#CCCatmullRomBy] create
-- @param #float duration
-- @param CCPointArray#CCPointArray points
-- @param #float tension
-- @return CCCardinalSplineTo#CCCardinalSplineTo

--------------------------------
-- @function [parent=#CCCatmullRomBy] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCatmullRomBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCatmullRomBy] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCCatmullRomBy] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCatmullRomBy] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCatmullRomBy] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCatmullRomBy] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCatmullRomBy] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCCatmullRomBy] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCCatmullRomBy] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCatmullRomBy] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCatmullRomBy] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCatmullRomBy] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCatmullRomBy] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCCatmullRomBy] release
-- @param self

--------------------------------
-- @function [parent=#CCCatmullRomBy] retain
-- @param self

--------------------------------
-- @function [parent=#CCCatmullRomBy] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCatmullRomBy] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCatmullRomBy] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCCatmullRomBy] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCCatmullRomBy] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
