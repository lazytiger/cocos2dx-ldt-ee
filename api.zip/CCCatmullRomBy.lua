--------------------------------
-- @type CCCatmullRomBy
-- @extends CCCardinalSplineBy#CCCardinalSplineBy

--------------------------------
-- @function [parent=#CCCatmullRomBy] create
-- @param self
-- @param #float dt
-- @param CCPointArray#CCPointArray points
-- @return #CCCatmullRomBy

return nil
