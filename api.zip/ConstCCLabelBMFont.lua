--------------------------------
-- @field [parent=#global] # kCCLabelAutomaticWidth

-------------------------------
-- @field [parent=#global] CCLabelBMFont#CCLabelBMFont CCLabelBMFont preloaded module

