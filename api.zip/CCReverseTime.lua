--------------------------------
-- @module CCReverseTime

--------------------------------
-- @function [parent=#CCReverseTime] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCReverseTime] create
-- @param self
-- @param CCFiniteTimeAction#CCFiniteTimeAction pAction
-- @return #CCReverseTime

--------------------------------
-- @function [parent=#CCReverseTime] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCReverseTime] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCReverseTime] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCReverseTime] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCReverseTime] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCReverseTime] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCReverseTime] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCReverseTime] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCReverseTime] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCReverseTime] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCReverseTime] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCReverseTime] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCReverseTime] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCReverseTime] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCReverseTime] release
-- @param self

--------------------------------
-- @function [parent=#CCReverseTime] retain
-- @param self

--------------------------------
-- @function [parent=#CCReverseTime] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCReverseTime] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCReverseTime] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCReverseTime] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCReverseTime] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
