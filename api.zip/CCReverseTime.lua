--------------------------------
-- @type CCReverseTime
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCReverseTime] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCReverseTime] create
-- @param self
-- @param CCFiniteTimeAction#CCFiniteTimeAction pAction
-- @return #CCReverseTime

return nil
