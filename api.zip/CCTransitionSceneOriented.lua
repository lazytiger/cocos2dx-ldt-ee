--------------------------------
-- @type CCTransitionSceneOriented
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionSceneOriented] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @param #tOrientation o
-- @return #CCTransitionSceneOriented

return nil
