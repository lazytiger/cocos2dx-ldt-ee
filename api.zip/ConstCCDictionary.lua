-------------------------------
-- @field [parent=#global] CCDictionary#CCDictionary CCDictionary preloaded module

-------------------------------
-- @field [parent=#global] CCDictionary#CCDictionary CCDictionary preloaded module

-------------------------------
-- @field [parent=#global] CCDictionary#CCDictionary CCDictionary preloaded module

-------------------------------
-- @field [parent=#global] CCDictionary#CCDictionary CCDictionary preloaded module

