--------------------------------
-- @type CCTransitionRotoZoom
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionRotoZoom] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionRotoZoom

return nil
