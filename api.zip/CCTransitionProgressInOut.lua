--------------------------------
-- @type CCTransitionProgressInOut
-- @extends CCTransitionProgress#CCTransitionProgress

--------------------------------
-- @function [parent=#CCTransitionProgressInOut] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionProgressInOut

return nil
