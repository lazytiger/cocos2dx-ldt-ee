--------------------------------
-- @field [parent=#global] # kCCTableViewFillTopDown

--------------------------------
-- @field [parent=#global] # kCCTableViewFillBottomUp

-------------------------------
-- @field [parent=#global] CCTableViewCell:#CCTableViewCell: CCTableViewCell: preloaded module

-------------------------------
-- @field [parent=#global] CCTableView#CCTableView CCTableView preloaded module

