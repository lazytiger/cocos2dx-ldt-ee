--------------------------------
-- @type CCTransitionTurnOffTiles
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionTurnOffTiles] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionTurnOffTiles

return nil
