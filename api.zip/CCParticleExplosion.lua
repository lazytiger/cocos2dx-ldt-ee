--------------------------------
-- @type CCParticleExplosion
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleExplosion] create
-- @param self
-- @return #CCParticleExplosion

return nil
