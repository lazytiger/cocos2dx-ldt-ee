--------------------------------
-- @type CCAccelDeccelAmplitude
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] getRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] setRate
-- @param self
-- @param #float fRate

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] create
-- @param self
-- @param CCAction#CCAction pAction
-- @param #float duration
-- @return #CCAccelDeccelAmplitude

return nil
