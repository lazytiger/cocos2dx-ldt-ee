--------------------------------
-- @module CCAccelDeccelAmplitude

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] getRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] setRate
-- @param self
-- @param #float fRate

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] create
-- @param self
-- @param CCAction#CCAction pAction
-- @param #float duration
-- @return #CCAccelDeccelAmplitude

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] release
-- @param self

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] retain
-- @param self

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCAccelDeccelAmplitude] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
