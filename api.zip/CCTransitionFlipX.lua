--------------------------------
-- @type CCTransitionFlipX
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionFlipX] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene s
-- @param #tOrientation o
-- @return #CCTransitionFlipX

return nil
