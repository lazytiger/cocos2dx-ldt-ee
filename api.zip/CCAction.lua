--------------------------------
-- @module CCAction

--------------------------------
-- @function [parent=#CCAction] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAction] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCAction] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCAction] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCAction] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCAction] release
-- @param self

--------------------------------
-- @function [parent=#CCAction] retain
-- @param self

--------------------------------
-- @function [parent=#CCAction] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAction] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCAction] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCAction] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCAction] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
