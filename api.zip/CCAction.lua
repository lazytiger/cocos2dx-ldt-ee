--------------------------------
-- @type CCAction
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCAction] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCAction] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCAction] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCAction] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCAction] setTag
-- @param self
-- @param #int nTag

return nil
