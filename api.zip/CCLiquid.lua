--------------------------------
-- @type CCLiquid
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCLiquid] getAmplitude
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCLiquid] setAmplitude
-- @param self
-- @param #float fAmplitude

--------------------------------
-- @function [parent=#CCLiquid] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCLiquid] setAmplitudeRate
-- @param self
-- @param #float fAmplitudeRate

--------------------------------
-- @function [parent=#CCLiquid] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int waves
-- @param #float amplitude
-- @return #CCLiquid

return nil
