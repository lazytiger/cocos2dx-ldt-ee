-------------------------------
-- @field [parent=#global] CCTMXObjectGroup#CCTMXObjectGroup CCTMXObjectGroup preloaded module

-------------------------------
-- @field [parent=#global] CCTMXObjectGroup#CCTMXObjectGroup CCTMXObjectGroup preloaded module

-------------------------------
-- @field [parent=#global] CCTMXObjectGroup#CCTMXObjectGroup CCTMXObjectGroup preloaded module

-------------------------------
-- @field [parent=#global] CCTMXObjectGroup#CCTMXObjectGroup CCTMXObjectGroup preloaded module

