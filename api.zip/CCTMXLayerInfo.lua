--------------------------------
-- @module CCTMXLayerInfo

--------------------------------
-- @function [parent=#CCTMXLayerInfo] getProperties
-- @param self
-- @return CCDictionary#CCDictionary

--------------------------------
-- @function [parent=#CCTMXLayerInfo] setProperties
-- @param self
-- @param CCDictionary#CCDictionary pval

--------------------------------
-- @function [parent=#CCTMXLayerInfo] release
-- @param self

--------------------------------
-- @function [parent=#CCTMXLayerInfo] retain
-- @param self

--------------------------------
-- @function [parent=#CCTMXLayerInfo] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTMXLayerInfo] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTMXLayerInfo] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCTMXLayerInfo] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCTMXLayerInfo] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
