--------------------------------
-- @type CCTMXLayerInfo
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCTMXLayerInfo] getProperties
-- @param self
-- @return CCDictionary#CCDictionary

--------------------------------
-- @function [parent=#CCTMXLayerInfo] setProperties
-- @param self
-- @param CCDictionary#CCDictionary pval

return nil
