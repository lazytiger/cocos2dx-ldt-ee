--------------------------------
-- @type CCLens3D
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCLens3D] getLensEffect
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCLens3D] setLensEffect
-- @param self
-- @param #float fLensEffect

--------------------------------
-- @function [parent=#CCLens3D] getPosition
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCLens3D] setPosition
-- @param self
-- @param CCPoint#CCPoint position

--------------------------------
-- @function [parent=#CCLens3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param CCPoint#CCPoint position
-- @param #float radius
-- @return #CCLens3D

return nil
