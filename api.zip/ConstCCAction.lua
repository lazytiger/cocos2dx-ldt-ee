--------------------------------
-- @field [parent=#global] # kCCActionTagInvalid

-------------------------------
-- @field [parent=#global] CCAction#CCAction CCAction preloaded module

-------------------------------
-- @field [parent=#global] CCFiniteTimeAction#CCFiniteTimeAction CCFiniteTimeAction preloaded module

-------------------------------
-- @field [parent=#global] CCActionInterval#CCActionInterval CCActionInterval preloaded module

-------------------------------
-- @field [parent=#global] CCSpeed#CCSpeed CCSpeed preloaded module

-------------------------------
-- @field [parent=#global] CCFollow#CCFollow CCFollow preloaded module

-------------------------------
-- @field [parent=#global] CCSequence#CCSequence CCSequence preloaded module

-------------------------------
-- @field [parent=#global] CCRepeat#CCRepeat CCRepeat preloaded module

-------------------------------
-- @field [parent=#global] CCRepeatForever#CCRepeatForever CCRepeatForever preloaded module

-------------------------------
-- @field [parent=#global] CCSpawn#CCSpawn CCSpawn preloaded module

-------------------------------
-- @field [parent=#global] CCRotateTo#CCRotateTo CCRotateTo preloaded module

-------------------------------
-- @field [parent=#global] CCRotateBy#CCRotateBy CCRotateBy preloaded module

-------------------------------
-- @field [parent=#global] CCMoveTo#CCMoveTo CCMoveTo preloaded module

-------------------------------
-- @field [parent=#global] CCMoveBy#CCMoveBy CCMoveBy preloaded module

-------------------------------
-- @field [parent=#global] CCSkewTo#CCSkewTo CCSkewTo preloaded module

-------------------------------
-- @field [parent=#global] CCSkewBy#CCSkewBy CCSkewBy preloaded module

-------------------------------
-- @field [parent=#global] CCJumpBy#CCJumpBy CCJumpBy preloaded module

-------------------------------
-- @field [parent=#global] CCJumpTo#CCJumpTo CCJumpTo preloaded module

-------------------------------
-- @field [parent=#global] ccBezierConfig#ccBezierConfig ccBezierConfig preloaded module

-------------------------------
-- @field [parent=#global] CCBezierBy#CCBezierBy CCBezierBy preloaded module

-------------------------------
-- @field [parent=#global] CCBezierTo#CCBezierTo CCBezierTo preloaded module

-------------------------------
-- @field [parent=#global] CCScaleTo#CCScaleTo CCScaleTo preloaded module

-------------------------------
-- @field [parent=#global] CCScaleBy#CCScaleBy CCScaleBy preloaded module

-------------------------------
-- @field [parent=#global] CCBlink#CCBlink CCBlink preloaded module

-------------------------------
-- @field [parent=#global] CCFadeIn#CCFadeIn CCFadeIn preloaded module

-------------------------------
-- @field [parent=#global] CCFadeOut#CCFadeOut CCFadeOut preloaded module

-------------------------------
-- @field [parent=#global] CCFadeTo#CCFadeTo CCFadeTo preloaded module

-------------------------------
-- @field [parent=#global] CCTintTo#CCTintTo CCTintTo preloaded module

-------------------------------
-- @field [parent=#global] CCTintBy#CCTintBy CCTintBy preloaded module

-------------------------------
-- @field [parent=#global] CCDelayTime#CCDelayTime CCDelayTime preloaded module

-------------------------------
-- @field [parent=#global] CCReverseTime#CCReverseTime CCReverseTime preloaded module

-------------------------------
-- @field [parent=#global] CCAnimate#CCAnimate CCAnimate preloaded module

-------------------------------
-- @field [parent=#global] CCTargetedAction#CCTargetedAction CCTargetedAction preloaded module

-------------------------------
-- @field [parent=#global] CCActionInstant#CCActionInstant CCActionInstant preloaded module

-------------------------------
-- @field [parent=#global] CCShow#CCShow CCShow preloaded module

-------------------------------
-- @field [parent=#global] CCHide#CCHide CCHide preloaded module

-------------------------------
-- @field [parent=#global] CCToggleVisibility#CCToggleVisibility CCToggleVisibility preloaded module

-------------------------------
-- @field [parent=#global] CCFlipX#CCFlipX CCFlipX preloaded module

-------------------------------
-- @field [parent=#global] CCFlipY#CCFlipY CCFlipY preloaded module

-------------------------------
-- @field [parent=#global] CCPlace#CCPlace CCPlace preloaded module

-------------------------------
-- @field [parent=#global] CCCallFunc#CCCallFunc CCCallFunc preloaded module

-------------------------------
-- @field [parent=#global] CCCallFuncN#CCCallFuncN CCCallFuncN preloaded module

