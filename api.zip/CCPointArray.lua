--------------------------------
-- @type CCPointArray
-- @extends CCNode#CCNode

--------------------------------
-- @function [parent=#CCPointArray] initWithCapacity
-- @param self
-- @param #int capacity
-- @return #bool

--------------------------------
-- @function [parent=#CCPointArray] addControlPoint
-- @param self
-- @param CCPoint#CCPoint controlPoint

--------------------------------
-- @function [parent=#CCPointArray] insertControlPoint
-- @param self
-- @param CCPoint#CCPoint controlPoint
-- @param #int index

--------------------------------
-- @function [parent=#CCPointArray] replaceControlPoint
-- @param self
-- @param CCPoint#CCPoint controlPoint
-- @param #int index

--------------------------------
-- @function [parent=#CCPointArray] getControlPointAtIndex
-- @param self
-- @param #int index
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCPointArray] removeControlPointAtIndex
-- @param self
-- @param #int index

--------------------------------
-- @function [parent=#CCPointArray] count
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCPointArray] reverse
-- @param self
-- @return #CCPointArray

--------------------------------
-- @function [parent=#CCPointArray] reverseInline
-- @param self

--------------------------------
-- @function [parent=#CCPointArray] getControlPoints
-- @param self
-- @return #std::vector<CCPoint*>

--------------------------------
-- @function [parent=#CCPointArray] setControlPoints
-- @param self
-- @param #std::vector<CCPoint*> controlPoints

--------------------------------
-- @function [parent=#CCPointArray] create
-- @param self
-- @param #int capacity
-- @return #CCPointArray

return nil
