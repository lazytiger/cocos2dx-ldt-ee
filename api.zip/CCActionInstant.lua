--------------------------------
-- @module CCActionInstant

--------------------------------
-- @function [parent=#CCActionInstant] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCActionInstant] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInstant] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCActionInstant] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCActionInstant] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCActionInstant] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInstant] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCActionInstant] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCActionInstant] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCActionInstant] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCActionInstant] release
-- @param self

--------------------------------
-- @function [parent=#CCActionInstant] retain
-- @param self

--------------------------------
-- @function [parent=#CCActionInstant] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInstant] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCActionInstant] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCActionInstant] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCActionInstant] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
