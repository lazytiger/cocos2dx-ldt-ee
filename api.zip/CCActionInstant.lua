--------------------------------
-- @type CCActionInstant
-- @extends CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCActionInstant] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCActionInstant] isDone
-- @param self
-- @return #bool

return nil
