--------------------------------
-- @module CCEaseBackInOut

--------------------------------
-- @function [parent=#CCEaseBackInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackInOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBackInOut

--------------------------------
-- @function [parent=#CCEaseBackInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackInOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBackInOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackInOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseBackInOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackInOut] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackInOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackInOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseBackInOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseBackInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackInOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBackInOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBackInOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBackInOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseBackInOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseBackInOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseBackInOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackInOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBackInOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackInOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseBackInOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
