--------------------------------
-- @type CCEaseBackInOut
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBackInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBackInOut

return nil
