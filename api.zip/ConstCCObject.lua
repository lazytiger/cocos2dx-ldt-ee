-------------------------------
-- @field [parent=#global] CCObject#CCObject CCObject preloaded module

-------------------------------
-- @field [parent=#global] CCObject#CCObject CCObject preloaded module

-------------------------------
-- @field [parent=#global] CCObject#CCObject CCObject preloaded module

-------------------------------
-- @field [parent=#global] CCObject#CCObject CCObject preloaded module

