--------------------------------
-- @module CCTouch

--------------------------------
-- @function [parent=#CCTouch] getLocation
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] getPreviousLocation
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] getDelta
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] getLocationInView
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] getPreviousLocationInView
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] setTouchInfo
-- @param self
-- @param #int id
-- @param #float x
-- @param #float y

--------------------------------
-- @function [parent=#CCTouch] getID
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTouch] release
-- @param self

--------------------------------
-- @function [parent=#CCTouch] retain
-- @param self

--------------------------------
-- @function [parent=#CCTouch] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCTouch] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCTouch] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCTouch] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCTouch] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
