--------------------------------
-- @type CCTouch
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCTouch] getLocation
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] getPreviousLocation
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] getDelta
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] getLocationInView
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] getPreviousLocationInView
-- @param self
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#CCTouch] setTouchInfo
-- @param self
-- @param #int id
-- @param #float x
-- @param #float y

--------------------------------
-- @function [parent=#CCTouch] getID
-- @param self
-- @return #int

return nil
