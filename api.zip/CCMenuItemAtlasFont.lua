--------------------------------
-- @type CCMenuItemAtlasFont
-- @extends CCMenuItemLabel#CCMenuItemLabel

--------------------------------
-- @function [parent=#CCMenuItemAtlasFont] create
-- @param self
-- @param #char value
-- @param #char charMapFile
-- @param #int itemWidth
-- @param #int itemHeight
-- @param #char startCharMap
-- @return #CCMenuItemAtlasFont

return nil
