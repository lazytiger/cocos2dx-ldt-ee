--------------------------------
-- @type CCTransitionFadeTR
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionFadeTR] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionFadeTR

return nil
