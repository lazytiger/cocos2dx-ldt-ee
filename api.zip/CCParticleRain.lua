--------------------------------
-- @type CCParticleRain
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleRain] create
-- @param self
-- @return #CCParticleRain

return nil
