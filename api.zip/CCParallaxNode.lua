--------------------------------
-- @type CCParallaxNode
-- @extends CCNode#CCNode

--------------------------------
-- @function [parent=#CCParallaxNode] addChild
-- @param self
-- @param CCNode#CCNode child
-- @param #int z
-- @param CCPoint#CCPoint parallaxRatio
-- @param CCPoint#CCPoint positionOffset

--------------------------------
-- @function [parent=#CCParallaxNode] addChild
-- @param self
-- @param CCNode#CCNode child
-- @param #int zOrder
-- @param #int tag

--------------------------------
-- @function [parent=#CCParallaxNode] removeChild
-- @param self
-- @param CCNode#CCNode child
-- @param #bool cleanup

--------------------------------
-- @function [parent=#CCParallaxNode] removeAllChildrenWithCleanup
-- @param self
-- @param #bool cleanup

--------------------------------
-- @function [parent=#CCParallaxNode] visit
-- @param self

--------------------------------
-- @function [parent=#CCParallaxNode] create
-- @param self
-- @return #CCParallaxNode

return nil
