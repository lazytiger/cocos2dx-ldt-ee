--------------------------------
-- @function [parent=#global] CCPointMake
-- @param #float x
-- @param #float y
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#global] ccp
-- @param #float x
-- @param #float y
-- @return CCPoint#CCPoint

--------------------------------
-- @function [parent=#global] CCSizeMake
-- @param #float width
-- @param #float height
-- @return CCSize#CCSize

--------------------------------
-- @function [parent=#global] CCRectMake
-- @param #float x
-- @param #float y
-- @param #float width
-- @param #float height
-- @return CCRect#CCRect

-------------------------------
-- @field [parent=#global] CCPoint#CCPoint CCPoint preloaded module

-------------------------------
-- @field [parent=#global] CCSize#CCSize CCSize preloaded module

-------------------------------
-- @field [parent=#global] CCRect#CCRect CCRect preloaded module

