--------------------------------
-- @module CCFadeIn

--------------------------------
-- @function [parent=#CCFadeIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeIn] create
-- @param self
-- @param #float d
-- @return #CCFadeIn

--------------------------------
-- @function [parent=#CCFadeIn] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFadeIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFadeIn] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCFadeIn] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFadeIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeIn] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeIn] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCFadeIn] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCFadeIn] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCFadeIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFadeIn] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFadeIn] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCFadeIn] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFadeIn] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCFadeIn] release
-- @param self

--------------------------------
-- @function [parent=#CCFadeIn] retain
-- @param self

--------------------------------
-- @function [parent=#CCFadeIn] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCFadeIn] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCFadeIn] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCFadeIn] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCFadeIn] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
