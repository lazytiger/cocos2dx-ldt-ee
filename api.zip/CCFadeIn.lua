--------------------------------
-- @type CCFadeIn
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCFadeIn] create
-- @param self
-- @param #float d
-- @return #CCFadeIn

return nil
