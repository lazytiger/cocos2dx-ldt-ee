--------------------------------
-- @type CCTransitionSplitCols
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionSplitCols] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionSplitCols

return nil
