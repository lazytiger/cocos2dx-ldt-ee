--------------------------------
-- @type CCFadeOutTRTiles
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCFadeOutTRTiles] turnOnTile
-- @param self
-- @param CCPoint#CCPoint pos

--------------------------------
-- @function [parent=#CCFadeOutTRTiles] turnOffTile
-- @param self
-- @param CCPoint#CCPoint pos

--------------------------------
-- @function [parent=#CCFadeOutTRTiles] transformTile
-- @param self
-- @param CCPoint#CCPoint pos
-- @param #float distance

--------------------------------
-- @function [parent=#CCFadeOutTRTiles] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return #CCFadeOutTRTiles

return nil
