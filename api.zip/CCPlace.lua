--------------------------------
-- @type CCPlace
-- @extends //<NSCopying>#//<NSCopying>

--------------------------------
-- @function [parent=#CCPlace] create
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #CCPlace

return nil
