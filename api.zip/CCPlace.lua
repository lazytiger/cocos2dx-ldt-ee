--------------------------------
-- @module CCPlace

--------------------------------
-- @function [parent=#CCPlace] create
-- @param CCPoint#CCPoint pos
-- @return #CCPlace

return nil
