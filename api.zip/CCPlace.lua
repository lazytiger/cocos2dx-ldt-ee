--------------------------------
-- @module CCPlace

--------------------------------
-- @function [parent=#CCPlace] create
-- @param self
-- @param CCPoint#CCPoint pos
-- @return #CCPlace

return nil
