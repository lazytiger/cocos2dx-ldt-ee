-------------------------------
-- @field [parent=#global] CCTouch#CCTouch CCTouch preloaded module

-------------------------------
-- @field [parent=#global] CCEvent#CCEvent CCEvent preloaded module

-------------------------------
-- @field [parent=#global] CCTouch#CCTouch CCTouch preloaded module

-------------------------------
-- @field [parent=#global] CCEvent#CCEvent CCEvent preloaded module

-------------------------------
-- @field [parent=#global] CCTouch#CCTouch CCTouch preloaded module

-------------------------------
-- @field [parent=#global] CCEvent#CCEvent CCEvent preloaded module

-------------------------------
-- @field [parent=#global] CCTouch#CCTouch CCTouch preloaded module

-------------------------------
-- @field [parent=#global] CCEvent#CCEvent CCEvent preloaded module

