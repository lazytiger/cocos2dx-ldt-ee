--------------------------------
-- @type CCSkewTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSkewTo] create
-- @param self
-- @param #float t
-- @param #float sx
-- @param #float sy
-- @return #CCSkewTo

return nil
