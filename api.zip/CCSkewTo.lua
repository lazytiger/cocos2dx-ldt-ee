--------------------------------
-- @module CCSkewTo

--------------------------------
-- @function [parent=#CCSkewTo] create
-- @param #float t
-- @param #float sx
-- @param #float sy
-- @return #CCSkewTo

--------------------------------
-- @function [parent=#CCSkewTo] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSkewTo] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSkewTo] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCSkewTo] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSkewTo] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSkewTo] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSkewTo] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSkewTo] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCSkewTo] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCSkewTo] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSkewTo] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCSkewTo] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCSkewTo] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSkewTo] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCSkewTo] release
-- @param self

--------------------------------
-- @function [parent=#CCSkewTo] retain
-- @param self

--------------------------------
-- @function [parent=#CCSkewTo] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSkewTo] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSkewTo] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCSkewTo] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCSkewTo] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
