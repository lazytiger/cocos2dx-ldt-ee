-------------------------------
-- @field [parent=#global] CCLabelAtlas#CCLabelAtlas CCLabelAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCLabelAtlas#CCLabelAtlas CCLabelAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCLabelAtlas#CCLabelAtlas CCLabelAtlas preloaded module

-------------------------------
-- @field [parent=#global] CCLabelAtlas#CCLabelAtlas CCLabelAtlas preloaded module

