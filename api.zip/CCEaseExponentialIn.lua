--------------------------------
-- @type CCEaseExponentialIn
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseExponentialIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseExponentialIn

return nil
