--------------------------------
-- @module CCEaseExponentialIn

--------------------------------
-- @function [parent=#CCEaseExponentialIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialIn] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseExponentialIn

--------------------------------
-- @function [parent=#CCEaseExponentialIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialIn] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseExponentialIn] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseExponentialIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseExponentialIn] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseExponentialIn] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseExponentialIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialIn] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseExponentialIn] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseExponentialIn] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseExponentialIn] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseExponentialIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseExponentialIn] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseExponentialIn] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseExponentialIn] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseExponentialIn] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseExponentialIn] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseExponentialIn] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseExponentialIn] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseExponentialIn] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseExponentialIn] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseExponentialIn] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseExponentialIn] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
