--------------------------------
-- @type CCCardinalSplineTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCardinalSplineTo] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCardinalSplineTo] getPoints
-- @param self
-- @return CCPointArray#CCPointArray

--------------------------------
-- @function [parent=#CCCardinalSplineTo] setPoints
-- @param self
-- @param CCPointArray#CCPointArray points

--------------------------------
-- @function [parent=#CCCardinalSplineTo] create
-- @param self
-- @param #float duration
-- @param CCPointArray#CCPointArray points
-- @param #float tension
-- @return #CCCardinalSplineTo

return nil
