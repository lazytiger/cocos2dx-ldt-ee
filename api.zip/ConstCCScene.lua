-------------------------------
-- @field [parent=#global] CCScene#CCScene CCScene preloaded module

-------------------------------
-- @field [parent=#global] CCScene#CCScene CCScene preloaded module

-------------------------------
-- @field [parent=#global] CCScene#CCScene CCScene preloaded module

-------------------------------
-- @field [parent=#global] CCScene#CCScene CCScene preloaded module

