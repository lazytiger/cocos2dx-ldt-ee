--------------------------------
-- @type CCProgressFromTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCProgressFromTo] create
-- @param self
-- @param #float duration
-- @param #float fFromPercentage
-- @param #float fToPercentage
-- @return #CCProgressFromTo

return nil
