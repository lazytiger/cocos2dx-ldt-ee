--------------------------------
-- @field [parent=#global] # kCCParticleDurationInfinity

--------------------------------
-- @field [parent=#global] # kCCParticleStartSizeEqualToEndSize

--------------------------------
-- @field [parent=#global] # kCCParticleStartRadiusEqualToEndRadius

--------------------------------
-- @field [parent=#global] # kParticleStartSizeEqualToEndSize

--------------------------------
-- @field [parent=#global] # kParticleDurationInfinity

--------------------------------
-- @field [parent=#global] # kCCParticleModeGravity

--------------------------------
-- @field [parent=#global] # kCCParticleModeRadius

--------------------------------
-- @field [parent=#global] #tCCPositionType kCCPositionTypeFree

--------------------------------
-- @field [parent=#global] #tCCPositionType kCCPositionTypeRelative

--------------------------------
-- @field [parent=#global] #tCCPositionType kCCPositionTypeGrouped

--------------------------------
-- @field [parent=#global] # kPositionTypeFree

--------------------------------
-- @field [parent=#global] # kPositionTypeGrouped

-------------------------------
-- @field [parent=#global] CCParticleSystem#CCParticleSystem CCParticleSystem preloaded module

-------------------------------
-- @field [parent=#global] CCParticleSystemQuad#CCParticleSystemQuad CCParticleSystemQuad preloaded module

