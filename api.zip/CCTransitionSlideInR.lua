--------------------------------
-- @type CCTransitionSlideInR
-- @extends CCScene#CCScene

--------------------------------
-- @function [parent=#CCTransitionSlideInR] create
-- @param self
-- @param #float t
-- @param CCScene#CCScene scene
-- @return #CCTransitionSlideInR

return nil
