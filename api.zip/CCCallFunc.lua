--------------------------------
-- @type CCCallFunc
-- @extends CCActionInstant#CCActionInstant

--------------------------------
-- @function [parent=#CCCallFunc] create
-- @param self
-- @param #LUA_FUNCTION funcID
-- @return #CCCallFunc

return nil
