--------------------------------
-- @module CCCallFunc

--------------------------------
-- @function [parent=#CCCallFunc] create
-- @param #LUA_FUNCTION funcID
-- @return #CCCallFunc

--------------------------------
-- @function [parent=#CCCallFunc] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCCallFunc] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCallFunc] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCallFunc] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCCallFunc] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCCallFunc] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCallFunc] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCallFunc] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCallFunc] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCallFunc] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCCallFunc] release
-- @param self

--------------------------------
-- @function [parent=#CCCallFunc] retain
-- @param self

--------------------------------
-- @function [parent=#CCCallFunc] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCallFunc] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCallFunc] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCCallFunc] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCCallFunc] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
