--------------------------------
-- @type CCParticleMeteor
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleMeteor] create
-- @param self
-- @return #CCParticleMeteor

return nil
