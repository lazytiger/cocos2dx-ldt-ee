--------------------------------
-- @type ccTex2F
-- @extends #

--------------------------------
-- @field [parent=#ccTex2F] #GLfloat u

--------------------------------
-- @field [parent=#ccTex2F] #GLfloat v

return nil
