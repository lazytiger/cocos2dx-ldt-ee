--------------------------------
-- @module ccTex2F

--------------------------------
-- @field [parent=#ccTex2F] #GLfloat u

--------------------------------
-- @field [parent=#ccTex2F] #GLfloat v

return nil
