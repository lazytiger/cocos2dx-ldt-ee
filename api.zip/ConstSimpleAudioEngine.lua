-------------------------------
-- @field [parent=#global] SimpleAudioEngine#SimpleAudioEngine SimpleAudioEngine preloaded module

-------------------------------
-- @field [parent=#global] SimpleAudioEngine#SimpleAudioEngine SimpleAudioEngine preloaded module

-------------------------------
-- @field [parent=#global] SimpleAudioEngine#SimpleAudioEngine SimpleAudioEngine preloaded module

-------------------------------
-- @field [parent=#global] SimpleAudioEngine#SimpleAudioEngine SimpleAudioEngine preloaded module

