--------------------------------
-- @module CCScaleTo

--------------------------------
-- @function [parent=#CCScaleTo] create
-- @param self
-- @param #float duration
-- @param #float sx
-- @param #float sy
-- @return #CCScaleTo

--------------------------------
-- @function [parent=#CCScaleTo] create
-- @param self
-- @param #float duration
-- @param #float s
-- @return #CCScaleTo

--------------------------------
-- @function [parent=#CCScaleTo] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCScaleTo] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCScaleTo] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCScaleTo] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCScaleTo] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCScaleTo] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCScaleTo] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCScaleTo] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCScaleTo] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCScaleTo] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCScaleTo] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCScaleTo] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCScaleTo] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCScaleTo] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCScaleTo] release
-- @param self

--------------------------------
-- @function [parent=#CCScaleTo] retain
-- @param self

--------------------------------
-- @function [parent=#CCScaleTo] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCScaleTo] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCScaleTo] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCScaleTo] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCScaleTo] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
