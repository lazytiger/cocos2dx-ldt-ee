--------------------------------
-- @type CCScaleTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCScaleTo] create
-- @param self
-- @param #float duration
-- @param #float sx
-- @param #float sy
-- @return #CCScaleTo

--------------------------------
-- @function [parent=#CCScaleTo] create
-- @param self
-- @param #float duration
-- @param #float s
-- @return #CCScaleTo

return nil
