--------------------------------
-- @module CCEaseBounceIn

--------------------------------
-- @function [parent=#CCEaseBounceIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBounceIn

--------------------------------
-- @function [parent=#CCEaseBounceIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCEaseBounce#CCEaseBounce

--------------------------------
-- @function [parent=#CCEaseBounceIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBounceIn] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceIn] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseBounceIn] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceIn] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceIn] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounceIn] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseBounceIn] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseBounceIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceIn] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBounceIn] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBounceIn] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBounceIn] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseBounceIn] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseBounceIn] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseBounceIn] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceIn] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBounceIn] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounceIn] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseBounceIn] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
