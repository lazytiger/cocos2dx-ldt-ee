--------------------------------
-- @type CCEaseBounceIn
-- @extends CCEaseBounce#CCEaseBounce

--------------------------------
-- @function [parent=#CCEaseBounceIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounceIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBounceIn

return nil
