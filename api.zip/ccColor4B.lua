--------------------------------
-- @module ccColor4B

--------------------------------
-- @field [parent=#ccColor4B] #GLubyte r

--------------------------------
-- @field [parent=#ccColor4B] #GLubyte g

--------------------------------
-- @field [parent=#ccColor4B] #GLubyte b

--------------------------------
-- @field [parent=#ccColor4B] #GLubyte a

return nil
