--------------------------------
-- @type CCParticleSystemQuad
-- @extends CCParticleSystem#CCParticleSystem

--------------------------------
-- @function [parent=#CCParticleSystemQuad] postStep
-- @param self

--------------------------------
-- @function [parent=#CCParticleSystemQuad] setDisplayFrame
-- @param self
-- @param CCSpriteFrame#CCSpriteFrame spriteFrame

--------------------------------
-- @function [parent=#CCParticleSystemQuad] setTexture
-- @param self
-- @param CCTexture2D#CCTexture2D texture

--------------------------------
-- @function [parent=#CCParticleSystemQuad] setTextureWithRect
-- @param self
-- @param CCTexture2D#CCTexture2D texture
-- @param CCRect#CCRect rect

--------------------------------
-- @function [parent=#CCParticleSystemQuad] setBatchNode
-- @param self
-- @param CCParticleBatchNode#CCParticleBatchNode batchNode

--------------------------------
-- @function [parent=#CCParticleSystemQuad] setTotalParticles
-- @param self
-- @param #int tp

--------------------------------
-- @function [parent=#CCParticleSystemQuad] updateQuadWithParticle
-- @param self
-- @param #tCCParticle particle
-- @param CCPoint#CCPoint newPosition

--------------------------------
-- @function [parent=#CCParticleSystemQuad] postStep
-- @param self

--------------------------------
-- @function [parent=#CCParticleSystemQuad] setTotalParticles
-- @param self
-- @param #int tp

--------------------------------
-- @function [parent=#CCParticleSystemQuad] create
-- @param self
-- @param #char plistFile
-- @return #CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleSystemQuad] create
-- @param self
-- @return #CCParticleSystemQuad

return nil
