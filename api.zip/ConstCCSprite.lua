-------------------------------
-- @field [parent=#global] CCSprite#CCSprite CCSprite preloaded module

-------------------------------
-- @field [parent=#global] CCSprite#CCSprite CCSprite preloaded module

-------------------------------
-- @field [parent=#global] CCSprite#CCSprite CCSprite preloaded module

-------------------------------
-- @field [parent=#global] CCSprite#CCSprite CCSprite preloaded module

