--------------------------------
-- @type CCShuffleTiles
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCShuffleTiles] shuffle
-- @param self
-- @param #int pArray
-- @param #int nLen

--------------------------------
-- @function [parent=#CCShuffleTiles] getDelta
-- @param self
-- @param CCSize#CCSize pos
-- @return CCSize#CCSize

--------------------------------
-- @function [parent=#CCShuffleTiles] placeTile
-- @param self
-- @param CCPoint#CCPoint pos
-- @param #Tile t

--------------------------------
-- @function [parent=#CCShuffleTiles] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int seed
-- @return #CCShuffleTiles

return nil
