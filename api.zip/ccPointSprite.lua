--------------------------------
-- @type ccPointSprite
-- @extends #

--------------------------------
-- @field [parent=#ccPointSprite] #ccVertex2F pos

--------------------------------
-- @field [parent=#ccPointSprite] #ccColor4B color

--------------------------------
-- @field [parent=#ccPointSprite] #GLfloat size

return nil
