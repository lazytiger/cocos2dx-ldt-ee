--------------------------------
-- @module CCReuseGrid

--------------------------------
-- @function [parent=#CCReuseGrid] create
-- @param self
-- @param #int times
-- @return #CCReuseGrid

--------------------------------
-- @function [parent=#CCReuseGrid] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCReuseGrid] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCReuseGrid] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCReuseGrid] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCReuseGrid] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCReuseGrid] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCReuseGrid] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCReuseGrid] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCReuseGrid] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCReuseGrid] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCReuseGrid] release
-- @param self

--------------------------------
-- @function [parent=#CCReuseGrid] retain
-- @param self

--------------------------------
-- @function [parent=#CCReuseGrid] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCReuseGrid] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCReuseGrid] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCReuseGrid] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCReuseGrid] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
