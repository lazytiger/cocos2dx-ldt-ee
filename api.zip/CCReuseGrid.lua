--------------------------------
-- @type CCReuseGrid
-- @extends CCActionInstant#CCActionInstant

--------------------------------
-- @function [parent=#CCReuseGrid] create
-- @param self
-- @param #int times
-- @return #CCReuseGrid

return nil
