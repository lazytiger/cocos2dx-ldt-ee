--------------------------------
-- @type CCParticleSpiral
-- @extends CCParticleSystemQuad#CCParticleSystemQuad

--------------------------------
-- @function [parent=#CCParticleSpiral] create
-- @param self
-- @return #CCParticleSpiral

return nil
