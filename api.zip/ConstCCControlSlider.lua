-------------------------------
-- @field [parent=#global] CCControlSlider#CCControlSlider CCControlSlider preloaded module

-------------------------------
-- @field [parent=#global] CCControlSlider#CCControlSlider CCControlSlider preloaded module

-------------------------------
-- @field [parent=#global] CCControlSlider#CCControlSlider CCControlSlider preloaded module

-------------------------------
-- @field [parent=#global] CCControlSlider#CCControlSlider CCControlSlider preloaded module

