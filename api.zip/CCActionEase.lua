--------------------------------
-- @type CCActionEase
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCActionEase] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCActionEase] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCActionEase

return nil
