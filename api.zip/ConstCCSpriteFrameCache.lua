-------------------------------
-- @field [parent=#global] CCSpriteFrameCache#CCSpriteFrameCache CCSpriteFrameCache preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteFrameCache#CCSpriteFrameCache CCSpriteFrameCache preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteFrameCache#CCSpriteFrameCache CCSpriteFrameCache preloaded module

-------------------------------
-- @field [parent=#global] CCSpriteFrameCache#CCSpriteFrameCache CCSpriteFrameCache preloaded module

