--------------------------------
-- @module CCEaseBounce

--------------------------------
-- @function [parent=#CCEaseBounce] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounce] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBounce

--------------------------------
-- @function [parent=#CCEaseBounce] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounce] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBounce] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounce] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounce] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseBounce] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounce] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounce] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounce] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBounce] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseBounce] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseBounce] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounce] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBounce] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBounce] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBounce] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseBounce] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseBounce] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseBounce] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounce] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBounce] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBounce] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseBounce] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
