--------------------------------
-- @type CCEaseBounce
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBounce] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBounce] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBounce

return nil
