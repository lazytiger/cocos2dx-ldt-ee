--------------------------------
-- @type CCEaseBackIn
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBackIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackIn] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBackIn

return nil
