--------------------------------
-- @module CCEaseBackIn

--------------------------------
-- @function [parent=#CCEaseBackIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackIn] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseBackIn

--------------------------------
-- @function [parent=#CCEaseBackIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackIn] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseBackIn] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackIn] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseBackIn] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackIn] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackIn] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseBackIn] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseBackIn] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseBackIn] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseBackIn] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackIn] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBackIn] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseBackIn] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBackIn] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseBackIn] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseBackIn] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseBackIn] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackIn] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseBackIn] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseBackIn] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseBackIn] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
