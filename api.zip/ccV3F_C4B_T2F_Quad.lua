--------------------------------
-- @module ccV3F_C4B_T2F_Quad

--------------------------------
-- @field [parent=#ccV3F_C4B_T2F_Quad] #ccV3F_C4B_T2F tl

--------------------------------
-- @field [parent=#ccV3F_C4B_T2F_Quad] #ccV3F_C4B_T2F bl

--------------------------------
-- @field [parent=#ccV3F_C4B_T2F_Quad] #ccV3F_C4B_T2F tr

--------------------------------
-- @field [parent=#ccV3F_C4B_T2F_Quad] #ccV3F_C4B_T2F br

return nil
