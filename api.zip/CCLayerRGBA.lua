--------------------------------
-- @type CCLayerRGBA
-- @extends CCRGBAProtocol#CCRGBAProtocol

--------------------------------
-- @function [parent=#CCLayerRGBA] create
-- @param self
-- @return #CCLayerRGBA

--------------------------------
-- @function [parent=#CCLayerRGBA] init
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLayerRGBA] getOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCLayerRGBA] getDisplayedOpacity
-- @param self
-- @return #GLubyte

--------------------------------
-- @function [parent=#CCLayerRGBA] setOpacity
-- @param self
-- @param #GLubyte opacity

--------------------------------
-- @function [parent=#CCLayerRGBA] updateDisplayedOpacity
-- @param self
-- @param #GLubyte parentOpacity

--------------------------------
-- @function [parent=#CCLayerRGBA] isCascadeOpacityEnabled
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLayerRGBA] setCascadeOpacityEnabled
-- @param self
-- @param #bool cascadeOpacityEnabled

--------------------------------
-- @function [parent=#CCLayerRGBA] getColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCLayerRGBA] getDisplayedColor
-- @param self
-- @return #ccColor3B

--------------------------------
-- @function [parent=#CCLayerRGBA] setColor
-- @param self
-- @param #ccColor3B color

--------------------------------
-- @function [parent=#CCLayerRGBA] updateDisplayedColor
-- @param self
-- @param #ccColor3B parentColor

--------------------------------
-- @function [parent=#CCLayerRGBA] isCascadeColorEnabled
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLayerRGBA] setCascadeColorEnabled
-- @param self
-- @param #bool cascadeColorEnabled

--------------------------------
-- @function [parent=#CCLayerRGBA] setOpacityModifyRGB
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCLayerRGBA] isOpacityModifyRGB
-- @param self
-- @return #bool

return nil
