--------------------------------
-- @type CCBezierTo
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCBezierTo] create
-- @param self
-- @param #float t
-- @param #ccBezierConfig c
-- @return #CCBezierTo

return nil
