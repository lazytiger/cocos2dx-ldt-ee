--------------------------------
-- @module CCBlink

--------------------------------
-- @function [parent=#CCBlink] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCBlink] create
-- @param self
-- @param #float duration
-- @param #int uBlinks
-- @return #CCBlink

--------------------------------
-- @function [parent=#CCBlink] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCBlink] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCBlink] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCBlink] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCBlink] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCBlink] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCBlink] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCBlink] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCBlink] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCBlink] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCBlink] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCBlink] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCBlink] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCBlink] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCBlink] release
-- @param self

--------------------------------
-- @function [parent=#CCBlink] retain
-- @param self

--------------------------------
-- @function [parent=#CCBlink] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCBlink] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCBlink] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCBlink] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCBlink] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
