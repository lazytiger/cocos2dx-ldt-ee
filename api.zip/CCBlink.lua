--------------------------------
-- @type CCBlink
-- @extends CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCBlink] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCBlink] create
-- @param self
-- @param #float duration
-- @param #int uBlinks
-- @return #CCBlink

return nil
