-------------------------------
-- @field [parent=#global] CCWaves3D#CCWaves3D CCWaves3D preloaded module

-------------------------------
-- @field [parent=#global] CCFlipX3D#CCFlipX3D CCFlipX3D preloaded module

-------------------------------
-- @field [parent=#global] CCFlipY3D#CCFlipY3D CCFlipY3D preloaded module

-------------------------------
-- @field [parent=#global] CCLens3D#CCLens3D CCLens3D preloaded module

-------------------------------
-- @field [parent=#global] CCRipple3D#CCRipple3D CCRipple3D preloaded module

-------------------------------
-- @field [parent=#global] CCShaky3D#CCShaky3D CCShaky3D preloaded module

-------------------------------
-- @field [parent=#global] CCLiquid#CCLiquid CCLiquid preloaded module

-------------------------------
-- @field [parent=#global] CCWaves#CCWaves CCWaves preloaded module

-------------------------------
-- @field [parent=#global] CCTwirl#CCTwirl CCTwirl preloaded module

-------------------------------
-- @field [parent=#global] CCWaves3D#CCWaves3D CCWaves3D preloaded module

-------------------------------
-- @field [parent=#global] CCFlipX3D#CCFlipX3D CCFlipX3D preloaded module

-------------------------------
-- @field [parent=#global] CCFlipY3D#CCFlipY3D CCFlipY3D preloaded module

-------------------------------
-- @field [parent=#global] CCLens3D#CCLens3D CCLens3D preloaded module

-------------------------------
-- @field [parent=#global] CCRipple3D#CCRipple3D CCRipple3D preloaded module

-------------------------------
-- @field [parent=#global] CCShaky3D#CCShaky3D CCShaky3D preloaded module

-------------------------------
-- @field [parent=#global] CCLiquid#CCLiquid CCLiquid preloaded module

-------------------------------
-- @field [parent=#global] CCWaves#CCWaves CCWaves preloaded module

-------------------------------
-- @field [parent=#global] CCTwirl#CCTwirl CCTwirl preloaded module

-------------------------------
-- @field [parent=#global] CCWaves3D#CCWaves3D CCWaves3D preloaded module

-------------------------------
-- @field [parent=#global] CCFlipX3D#CCFlipX3D CCFlipX3D preloaded module

-------------------------------
-- @field [parent=#global] CCFlipY3D#CCFlipY3D CCFlipY3D preloaded module

-------------------------------
-- @field [parent=#global] CCLens3D#CCLens3D CCLens3D preloaded module

-------------------------------
-- @field [parent=#global] CCRipple3D#CCRipple3D CCRipple3D preloaded module

-------------------------------
-- @field [parent=#global] CCShaky3D#CCShaky3D CCShaky3D preloaded module

-------------------------------
-- @field [parent=#global] CCLiquid#CCLiquid CCLiquid preloaded module

-------------------------------
-- @field [parent=#global] CCWaves#CCWaves CCWaves preloaded module

-------------------------------
-- @field [parent=#global] CCTwirl#CCTwirl CCTwirl preloaded module

-------------------------------
-- @field [parent=#global] CCWaves3D#CCWaves3D CCWaves3D preloaded module

-------------------------------
-- @field [parent=#global] CCFlipX3D#CCFlipX3D CCFlipX3D preloaded module

-------------------------------
-- @field [parent=#global] CCFlipY3D#CCFlipY3D CCFlipY3D preloaded module

-------------------------------
-- @field [parent=#global] CCLens3D#CCLens3D CCLens3D preloaded module

-------------------------------
-- @field [parent=#global] CCRipple3D#CCRipple3D CCRipple3D preloaded module

-------------------------------
-- @field [parent=#global] CCShaky3D#CCShaky3D CCShaky3D preloaded module

-------------------------------
-- @field [parent=#global] CCLiquid#CCLiquid CCLiquid preloaded module

-------------------------------
-- @field [parent=#global] CCWaves#CCWaves CCWaves preloaded module

-------------------------------
-- @field [parent=#global] CCTwirl#CCTwirl CCTwirl preloaded module

