--------------------------------
-- @type CCLayer
-- @extends CCNode#CCNode

--------------------------------
-- @function [parent=#CCLayer] setTouchEnabled
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCLayer] isTouchEnabled
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLayer] setAccelerometerEnabled
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCLayer] isAccelerometerEnabled
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLayer] setKeypadEnabled
-- @param self
-- @param #bool bValue

--------------------------------
-- @function [parent=#CCLayer] isKeypadEnabled
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCLayer] setTouchMode
-- @param self
-- @param #ccTouchesMode mode

--------------------------------
-- @function [parent=#CCLayer] getTouchMode
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCLayer] setTouchPriority
-- @param self
-- @param #int priority

--------------------------------
-- @function [parent=#CCLayer] getTouchPriority
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCLayer] registerScriptTouchHandler
-- @param self
-- @param #LUA_FUNCTION nHandler
-- @param #bool bIsMultiTouches
-- @param #int nPriority
-- @param #bool bSwallowsTouches

--------------------------------
-- @function [parent=#CCLayer] unregisterScriptTouchHandler
-- @param self

--------------------------------
-- @function [parent=#CCLayer] registerScriptKeypadHandler
-- @param self
-- @param #LUA_FUNCTION nHandler

--------------------------------
-- @function [parent=#CCLayer] unregisterScriptKeypadHandler
-- @param self

--------------------------------
-- @function [parent=#CCLayer] registerScriptAccelerateHandler
-- @param self
-- @param #LUA_FUNCTION nHandler

--------------------------------
-- @function [parent=#CCLayer] unregisterScriptAccelerateHandler
-- @param self

--------------------------------
-- @function [parent=#CCLayer] create
-- @param self
-- @return #CCLayer

return nil
