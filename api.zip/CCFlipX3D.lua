--------------------------------
-- @type CCFlipX3D
-- @extends CCGrid3DAction#CCGrid3DAction

--------------------------------
-- @function [parent=#CCFlipX3D] create
-- @param self
-- @param #float duration
-- @return #CCFlipX3D

return nil
