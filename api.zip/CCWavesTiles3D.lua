--------------------------------
-- @type CCWavesTiles3D
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCWavesTiles3D] getAmplitude
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCWavesTiles3D] setAmplitude
-- @param self
-- @param #float fAmplitude

--------------------------------
-- @function [parent=#CCWavesTiles3D] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCWavesTiles3D] setAmplitudeRate
-- @param self
-- @param #float fAmplitudeRate

--------------------------------
-- @function [parent=#CCWavesTiles3D] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int waves
-- @param #float amplitude
-- @return #CCWavesTiles3D

return nil
