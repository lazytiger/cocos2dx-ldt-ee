--------------------------------
-- @type CCCatmullRomTo
-- @extends CCCardinalSplineTo#CCCardinalSplineTo

--------------------------------
-- @function [parent=#CCCatmullRomTo] create
-- @param self
-- @param #float dt
-- @param CCPointArray#CCPointArray points
-- @return #CCCatmullRomTo

return nil
