--------------------------------
-- @module CCCatmullRomTo

--------------------------------
-- @function [parent=#CCCatmullRomTo] create
-- @param self
-- @param #float dt
-- @param CCPointArray#CCPointArray points
-- @return #CCCatmullRomTo

--------------------------------
-- @function [parent=#CCCatmullRomTo] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCatmullRomTo] getPoints
-- @param self
-- @return CCPointArray#CCPointArray

--------------------------------
-- @function [parent=#CCCatmullRomTo] setPoints
-- @param self
-- @param CCPointArray#CCPointArray points

--------------------------------
-- @function [parent=#CCCatmullRomTo] create
-- @param self
-- @param #float duration
-- @param CCPointArray#CCPointArray points
-- @param #float tension
-- @return CCCardinalSplineTo#CCCardinalSplineTo

--------------------------------
-- @function [parent=#CCCatmullRomTo] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCatmullRomTo] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCatmullRomTo] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCCatmullRomTo] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCatmullRomTo] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCatmullRomTo] create
-- @param self
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCCatmullRomTo] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCCatmullRomTo] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCCatmullRomTo] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCCatmullRomTo] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCatmullRomTo] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCatmullRomTo] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCCatmullRomTo] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCatmullRomTo] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCCatmullRomTo] release
-- @param self

--------------------------------
-- @function [parent=#CCCatmullRomTo] retain
-- @param self

--------------------------------
-- @function [parent=#CCCatmullRomTo] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCCatmullRomTo] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCCatmullRomTo] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCCatmullRomTo] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCCatmullRomTo] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
