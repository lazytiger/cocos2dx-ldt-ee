--------------------------------
-- @field [parent=#global] # kKeyboardReturnTypeDefault

--------------------------------
-- @field [parent=#global] # kKeyboardReturnTypeDone

--------------------------------
-- @field [parent=#global] # kKeyboardReturnTypeSend

--------------------------------
-- @field [parent=#global] # kKeyboardReturnTypeSearch

--------------------------------
-- @field [parent=#global] # kKeyboardReturnTypeGo

--------------------------------
-- @field [parent=#global] # kEditBoxInputModeAny

--------------------------------
-- @field [parent=#global] # kEditBoxInputModeEmailAddr

--------------------------------
-- @field [parent=#global] # kEditBoxInputModeNumeric

--------------------------------
-- @field [parent=#global] # kEditBoxInputModePhoneNumber

--------------------------------
-- @field [parent=#global] # kEditBoxInputModeUrl

--------------------------------
-- @field [parent=#global] # kEditBoxInputModeDecimal

--------------------------------
-- @field [parent=#global] # kEditBoxInputModeSingleLine

--------------------------------
-- @field [parent=#global] # kEditBoxInputFlagPassword

--------------------------------
-- @field [parent=#global] # kEditBoxInputFlagSensitive

--------------------------------
-- @field [parent=#global] # kEditBoxInputFlagInitialCapsWord

--------------------------------
-- @field [parent=#global] # kEditBoxInputFlagInitialCapsSentence

--------------------------------
-- @field [parent=#global] # kEditBoxInputFlagInitialCapsAllCharacters

-------------------------------
-- @field [parent=#global] CCEditBox:#CCEditBox: CCEditBox: preloaded module

