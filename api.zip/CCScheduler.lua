--------------------------------
-- @type CCScheduler
-- @extends CCObject#CCObject

--------------------------------
-- @function [parent=#CCScheduler] getTimeScale
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCScheduler] setTimeScale
-- @param self
-- @param #float fTimeScale

--------------------------------
-- @function [parent=#CCScheduler] scheduleScriptFunc
-- @param self
-- @param #LUA_FUNCTION funcID
-- @param #float fInterval
-- @param #bool bPaused
-- @return #int

--------------------------------
-- @function [parent=#CCScheduler] unscheduleScriptEntry
-- @param self
-- @param #int uScheduleScriptEntryID

return nil
