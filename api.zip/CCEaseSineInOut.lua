--------------------------------
-- @module CCEaseSineInOut

--------------------------------
-- @function [parent=#CCEaseSineInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineInOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseSineInOut

--------------------------------
-- @function [parent=#CCEaseSineInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineInOut] create
-- @param CCActionInterval#CCActionInterval pAction
-- @return CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseSineInOut] getElapsed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseSineInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseSineInOut] setAmplitudeRate
-- @param self
-- @param #float amp

--------------------------------
-- @function [parent=#CCEaseSineInOut] getAmplitudeRate
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseSineInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineInOut] create
-- @param #float d
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineInOut] getDuration
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCEaseSineInOut] setDuration
-- @param self
-- @param #float duration

--------------------------------
-- @function [parent=#CCEaseSineInOut] reverse
-- @param self
-- @return CCFiniteTimeAction#CCFiniteTimeAction

--------------------------------
-- @function [parent=#CCEaseSineInOut] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseSineInOut] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseSineInOut] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCEaseSineInOut] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseSineInOut] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCEaseSineInOut] release
-- @param self

--------------------------------
-- @function [parent=#CCEaseSineInOut] retain
-- @param self

--------------------------------
-- @function [parent=#CCEaseSineInOut] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseSineInOut] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCEaseSineInOut] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCEaseSineInOut] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCEaseSineInOut] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
