--------------------------------
-- @type CCEaseSineInOut
-- @extends CCActionEase#CCActionEase

--------------------------------
-- @function [parent=#CCEaseSineInOut] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCEaseSineInOut] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @return #CCEaseSineInOut

return nil
