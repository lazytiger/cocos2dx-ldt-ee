--------------------------------
-- @type CCTurnOffTiles
-- @extends CCTiledGrid3DAction#CCTiledGrid3DAction

--------------------------------
-- @function [parent=#CCTurnOffTiles] shuffle
-- @param self
-- @param #int pArray
-- @param #int nLen

--------------------------------
-- @function [parent=#CCTurnOffTiles] turnOnTile
-- @param self
-- @param CCPoint#CCPoint pos

--------------------------------
-- @function [parent=#CCTurnOffTiles] turnOffTile
-- @param self
-- @param CCPoint#CCPoint pos

--------------------------------
-- @function [parent=#CCTurnOffTiles] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @return #CCTurnOffTiles

--------------------------------
-- @function [parent=#CCTurnOffTiles] create
-- @param self
-- @param #float duration
-- @param CCSize#CCSize gridSize
-- @param #int seed
-- @return #CCTurnOffTiles

return nil
