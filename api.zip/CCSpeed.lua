--------------------------------
-- @module CCSpeed

--------------------------------
-- @function [parent=#CCSpeed] getSpeed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSpeed] setSpeed
-- @param self
-- @param #float fSpeed

--------------------------------
-- @function [parent=#CCSpeed] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSpeed] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSpeed] create
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCSpeed

--------------------------------
-- @function [parent=#CCSpeed] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSpeed] getTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCSpeed] getOriginalTarget
-- @param self
-- @return CCNode#CCNode

--------------------------------
-- @function [parent=#CCSpeed] getTag
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSpeed] setTag
-- @param self
-- @param #int nTag

--------------------------------
-- @function [parent=#CCSpeed] release
-- @param self

--------------------------------
-- @function [parent=#CCSpeed] retain
-- @param self

--------------------------------
-- @function [parent=#CCSpeed] isSingleReference
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSpeed] retainCount
-- @param self
-- @return #int

--------------------------------
-- @function [parent=#CCSpeed] isEqual
-- @param self
-- @param CCObject#CCObject pObject
-- @return #bool

--------------------------------
-- @function [parent=#CCSpeed] copy
-- @param self
-- @return CCObject#CCObject

--------------------------------
-- @function [parent=#CCSpeed] autorelease
-- @param self
-- @return CCObject#CCObject

return nil
