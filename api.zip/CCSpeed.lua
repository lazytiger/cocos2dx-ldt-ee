--------------------------------
-- @type CCSpeed
-- @extends CCAction#CCAction

--------------------------------
-- @function [parent=#CCSpeed] getSpeed
-- @param self
-- @return #float

--------------------------------
-- @function [parent=#CCSpeed] setSpeed
-- @param self
-- @param #float fSpeed

--------------------------------
-- @function [parent=#CCSpeed] reverse
-- @param self
-- @return CCActionInterval#CCActionInterval

--------------------------------
-- @function [parent=#CCSpeed] isDone
-- @param self
-- @return #bool

--------------------------------
-- @function [parent=#CCSpeed] create
-- @param self
-- @param CCActionInterval#CCActionInterval pAction
-- @param #float fRate
-- @return #CCSpeed

return nil
