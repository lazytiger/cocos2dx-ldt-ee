-------------------------------
-- @field [parent=#global] CCParticleBatchNode#CCParticleBatchNode CCParticleBatchNode preloaded module

-------------------------------
-- @field [parent=#global] CCParticleBatchNode#CCParticleBatchNode CCParticleBatchNode preloaded module

-------------------------------
-- @field [parent=#global] CCParticleBatchNode#CCParticleBatchNode CCParticleBatchNode preloaded module

-------------------------------
-- @field [parent=#global] CCParticleBatchNode#CCParticleBatchNode CCParticleBatchNode preloaded module

