--------------------------------
-- @module kmMat4

--------------------------------
-- @field [parent=#kmMat4] #float mat

return nil
