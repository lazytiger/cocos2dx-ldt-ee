--------------------------------
-- @type kmMat4
-- @extends #

--------------------------------
-- @field [parent=#kmMat4] #float mat

return nil
